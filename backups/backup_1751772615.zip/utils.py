#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工具函数模块 - 提供基础工具函数支持
包含文件操作、路径处理、配置加载等功能
"""

import os
import sys
import pandas as pd
import subprocess
import shutil
from pathlib import Path


# 路径相关函数
def get_app_path():
    """
    获取应用程序根目录的绝对路径
    支持直接运行和打包成App后运行
    """
    if getattr(sys, 'frozen', False):
        # 如果应用被打包
        if hasattr(sys, '_MEIPASS'):
            # PyInstaller
            return Path(sys._MEIPASS)
        else:
            # py2app或其他
            return Path(os.path.dirname(os.path.dirname(sys.executable)))
    else:
        # 普通Python脚本
        return Path(os.path.dirname(os.path.abspath(__file__)))


def get_data_path(sub_dir=""):
    """
    获取数据目录路径
    
    参数:
        sub_dir: 子目录，如 "input/videos"
    
    返回:
        data目录下指定子目录的路径
    """
    data_path = get_app_path() / "data"
    
    # 如果sub_dir为空，确保data目录存在
    if not sub_dir:
        os.makedirs(data_path, exist_ok=True)
        return data_path
    
    # 分离路径和可能的文件名
    parts = Path(sub_dir).parts
    if '.' in parts[-1]:  # 最后一部分包含点，可能是文件
        dir_path = data_path.joinpath(*parts[:-1])  # 目录部分
        full_path = data_path / sub_dir  # 完整路径（包括可能的文件）
        
        # 只确保目录存在
        os.makedirs(dir_path, exist_ok=True)
        return full_path
    else:
        # 是纯目录路径
        full_path = data_path / sub_dir
        os.makedirs(full_path, exist_ok=True)
        return full_path


# 配置文件处理
def load_subtitle_config():
    """
    加载字幕配置文件(subtitle.csv)
    
    返回:
        pandas.DataFrame: 包含name、title、style等列的DataFrame
    """
    config_path = get_data_path("config") / "subtitle.csv"
    
    if not config_path.exists():
        # 如果配置文件不存在，创建一个空的
        df = pd.DataFrame(columns=["name", "title", "title_thai", "style"])
        df.to_csv(config_path, index=False, encoding="utf-8")
        print(f"创建了新的配置文件: {config_path}")
        return df
    
    try:
        # 尝试读取配置文件，确保使用UTF-8编码
        df = pd.read_csv(config_path, encoding="utf-8")
        print(f"成功加载配置: {config_path}")
        
        # 确保必要的列存在
        required_columns = ["name", "title", "style"]
        for col in required_columns:
            if col not in df.columns:
                df[col] = ""
        
        # 确保title_thai列存在
        if "title_thai" not in df.columns:
            df["title_thai"] = ""
                
        return df
    except UnicodeDecodeError:
        # 如果UTF-8解码失败，尝试其他编码
        try:
            df = pd.read_csv(config_path, encoding="ISO-8859-1")
            # 将数据转换为UTF-8
            df.to_csv(config_path, index=False, encoding="utf-8")
            print(f"配置文件已从其他编码转换为UTF-8: {config_path}")
            return df
        except Exception as e:
            print(f"读取配置文件失败(尝试其他编码): {e}")
            return pd.DataFrame(columns=["name", "title", "title_thai", "style"])
    except Exception as e:
        print(f"读取配置文件失败: {e}")
        # 返回一个空的DataFrame
        return pd.DataFrame(columns=["name", "title", "title_thai", "style"])


# 文件操作
def find_matching_file(base_name, directory, extensions=[".jpg", ".png", ".jpeg"]):
    """
    在指定目录中查找与base_name匹配的文件
    
    参数:
        base_name: 文件名基础部分(不含扩展名)
        directory: 要搜索的目录
        extensions: 要匹配的文件扩展名列表
    
    返回:
        找到的文件路径，如果没找到则返回None
    """
    directory_path = Path(directory)
    if not directory_path.exists():
        return None
    
    # 首先尝试完全匹配
    for ext in extensions:
        file_path = directory_path / f"{base_name}{ext}"
        if file_path.exists():
            return file_path
    
    # 如果没有完全匹配，尝试部分匹配
    for file in os.listdir(directory_path):
        file_base = os.path.splitext(file)[0].lower()
        if base_name.lower() in file_base or file_base in base_name.lower():
            file_path = directory_path / file
            if file_path.suffix.lower() in [ext.lower() for ext in extensions]:
                return file_path
    
    return None


# FFMPEG命令执行
def run_ffmpeg_command(command, quiet=False):
    """
    执行FFMPEG命令
    
    参数:
        command: 命令列表，如 ["ffmpeg", "-i", "input.mp4", "output.mp4"]
        quiet: 是否静默执行
    
    返回:
        成功返回True，失败返回False
    """
    if not quiet:
        print(f"执行命令: {' '.join(command)}")
    
    try:
        if quiet:
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            result = subprocess.run(command)
            
        return result.returncode == 0
    except Exception as e:
        print(f"执行命令失败: {e}")
        return False


def get_video_info(video_path):
    """
    获取视频信息(宽度、高度、时长)
    
    参数:
        video_path: 视频文件路径
    
    返回:
        (width, height, duration) 元组，失败返回None
    """
    try:
        # 获取视频尺寸
        size_cmd = [
            "ffprobe", "-v", "error", "-select_streams", "v:0",
            "-show_entries", "stream=width,height", "-of", "csv=s=x:p=0",
            str(video_path)
        ]
        video_size = subprocess.check_output(size_cmd).decode("utf-8").strip()
        width, height = map(int, video_size.split("x"))
        
        # 获取视频时长
        duration_cmd = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)
        ]
        duration_str = subprocess.check_output(duration_cmd).decode("utf-8").strip()
        
        # 确保获取到有效的时长值
        try:
            duration = float(duration_str)
            if duration <= 0.1:  # 如果时长异常短，尝试使用另一种方法
                print(f"警告: 检测到异常短的视频时长 ({duration}秒)，尝试使用另一种方法获取...")
                # 使用另一种方法获取时长
                alt_duration_cmd = [
                    "ffprobe", "-v", "error", "-select_streams", "v:0",
                    "-show_entries", "stream=duration", "-of", "default=noprint_wrappers=1:nokey=1",
                    str(video_path)
                ]
                alt_duration_str = subprocess.check_output(alt_duration_cmd).decode("utf-8").strip()
                if alt_duration_str and float(alt_duration_str) > 0.1:
                    duration = float(alt_duration_str)
                    print(f"使用流时长: {duration}秒")
                else:
                    # 如果流时长也不可用，使用帧数和帧率计算
                    frame_cmd = [
                        "ffprobe", "-v", "error", "-count_frames",
                        "-select_streams", "v:0", "-show_entries", "stream=nb_read_frames",
                        "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)
                    ]
                    fps_cmd = [
                        "ffprobe", "-v", "error", "-select_streams", "v:0",
                        "-show_entries", "stream=r_frame_rate", "-of", "default=noprint_wrappers=1:nokey=1",
                        str(video_path)
                    ]
                    
                    try:
                        frames = int(subprocess.check_output(frame_cmd).decode("utf-8").strip())
                        fps_str = subprocess.check_output(fps_cmd).decode("utf-8").strip()
                        fps_parts = fps_str.split('/')
                        if len(fps_parts) == 2:
                            fps = float(fps_parts[0]) / float(fps_parts[1])
                        else:
                            fps = float(fps_str)
                        
                        if frames > 0 and fps > 0:
                            duration = frames / fps
                            print(f"使用帧数计算时长: {frames}帧 / {fps}fps = {duration}秒")
                    except Exception as e:
                        print(f"帧数计算失败: {e}")
                        # 使用默认值
                        duration = 10.0
                        print(f"无法获取准确时长，使用默认值: {duration}秒")
        except ValueError:
            print(f"无法解析时长字符串: '{duration_str}'")
            duration = 10.0  # 使用默认值
            
        print(f"视频信息: {width}x{height}, {duration}秒")
        return width, height, duration
    except Exception as e:
        print(f"获取视频信息失败: {e}")
        # 返回默认值
        return 1080, 1920, 10.0  # 默认值


def ensure_dir(directory):
    """确保目录存在，不存在则创建"""
    os.makedirs(directory, exist_ok=True)


# 字幕生成函数
def create_subtitle_image(text, style="style1", width=1080, height=300, font_size=30, output_path=None):
    """
    创建字幕图片
    
    参数:
        text: 字幕文本
        style: 字幕样式
        width: 图片宽度
        height: 图片高度
        font_size: 字体大小
        output_path: 输出路径，如果为None则返回临时文件路径
        
    返回:
        字幕图片路径
    """
    try:
        import tempfile
        from PIL import Image, ImageDraw, ImageFont
        
        # 打印调试信息
        print(f"创建字幕图片: 宽={width}, 高={height}, 字体大小={font_size}, 样式={style}")
        print(f"字幕内容: {text}")
        
        # 如果未指定输出路径，创建临时文件
        if output_path is None:
            temp_file = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
            output_path = temp_file.name
            temp_file.close()
        
        # 创建透明背景图片
        image = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        
        # 检测是否包含泰文字符
        def contains_thai(s):
            # 泰文Unicode范围: 0E00-0E7F
            return any('\u0E00' <= c <= '\u0E7F' for c in s)
        
        is_thai_text = contains_thai(text)
        print(f"是否包含泰文: {is_thai_text}")
        
        # 使用系统字体
        # 优先查找泰文字体
        thai_fonts = [
            get_data_path("fonts") / "sukhumvitset-bold.ttf",  # 项目自带泰文字体
            get_data_path("fonts") / "sukhumvitset-semibold.ttf",
            "/Library/Fonts/Thonburi.ttc",  # macOS泰文字体
            "/System/Library/Fonts/Thonburi.ttc",
            "/System/Library/Fonts/Supplemental/Tahoma.ttf",  # 通常支持泰文
            "/Library/Fonts/Tahoma.ttf",
            "C:\\Windows\\Fonts\\tahoma.ttf",  # Windows泰文字体
        ]
        
        general_fonts = [
            "/System/Library/Fonts/STHeiti Medium.ttc",  # macOS中文字体
            "/System/Library/Fonts/Hiragino Sans GB.ttc",  # macOS中文字体
            "/System/Library/Fonts/Arial Unicode.ttf",   # macOS
            "/Library/Fonts/Arial Bold.ttf",             # macOS
            "/Library/Fonts/Arial.ttf",                  # macOS
            "C:\\Windows\\Fonts\\arial.ttf",             # Windows
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"  # Linux
        ]
        
        # 根据文本类型选择字体列表
        font_list = thai_fonts if is_thai_text else general_fonts
        
        # 查找可用字体
        font_path = None
        for font_file in font_list:
            if os.path.exists(str(font_file)):
                font_path = font_file
                print(f"找到可用字体: {font_path}")
                break
        
        if not font_path:
            print("未找到可用字体，尝试使用通用字体")
            # 如果没有找到特定语言的字体，尝试通用字体
            for font_file in general_fonts:
                if os.path.exists(str(font_file)):
                    font_path = font_file
                    print(f"找到通用字体: {font_path}")
                    break
        
        if not font_path:
            print("未找到任何可用字体，将使用默认字体")
        
        # 根据样式设置字体颜色和描边
        if style == "style1":
            text_color = (254, 248, 0, 255)  # 黄色，参考config.ini中的number_color
            stroke_color = (29, 58, 148, 255)  # 蓝色描边，参考config.ini中的stroke_color
            stroke_width = 6  # 参考config.ini中的number_blue_stroke_px
            # 添加额外的白色描边
            white_stroke_width = int(stroke_width * 1.3)  # 参考config.ini中的number_white_stroke_ratio
            white_stroke_color = (255, 255, 255, 255)
            shadow = True
            shadow_color = (0, 0, 0, 120)  # 参考config.ini中的shadow_color
            shadow_offset = (8, 8)  # 参考config.ini中的shadow_offset
        elif style == "style2":
            text_color = (192, 236, 14, 255)  # 绿色，参考config.ini中的number_color
            stroke_color = (0, 51, 102, 255)  # 深蓝色描边，参考config.ini中的stroke_color
            stroke_width = 4  # 参考config.ini中的number_blue_stroke_px
            # 添加额外的白色描边
            white_stroke_width = int(stroke_width * 1.2)  # 参考config.ini中的number_white_stroke_ratio
            white_stroke_color = (255, 255, 255, 255)
            shadow = False
        elif style == "style3":
            text_color = (255, 255, 255, 255)  # 白色，参考config.ini中的number_color
            stroke_color = (255, 20, 147, 255)  # 粉色描边，参考config.ini中的stroke_color
            stroke_width = 6  # 参考config.ini中的number_blue_stroke_px
            # 添加额外的白色描边
            white_stroke_width = int(stroke_width * 1.5)  # 参考config.ini中的number_white_stroke_ratio
            white_stroke_color = (255, 255, 255, 255)
            shadow = True
            shadow_color = (50, 0, 30, 150)  # 参考config.ini中的shadow_color
            shadow_offset = (6, 6)  # 参考config.ini中的shadow_offset
        elif style == "style4":
            text_color = (255, 255, 255, 255)  # 白色，参考config.ini中的number_color
            stroke_color = (128, 0, 128, 255)  # 紫色描边，参考config.ini中的stroke_color
            stroke_width = 8  # 参考config.ini中的number_blue_stroke_px
            # 添加额外的白色描边
            white_stroke_width = int(stroke_width * 1.3)  # 参考config.ini中的number_white_stroke_ratio
            white_stroke_color = (255, 255, 255, 255)
            shadow = True
            shadow_color = (0, 0, 0, 120)  # 参考config.ini中的shadow_color
            shadow_offset = (3, 3)  # 参考config.ini中的shadow_offset
        elif style == "style5":
            text_color = (255, 140, 0, 255)  # 橙色，参考config.ini中的number_color
            stroke_color = (0, 71, 171, 255)  # 蓝色描边，参考config.ini中的stroke_color
            stroke_width = 8  # 参考config.ini中的number_blue_stroke_px
            # 添加额外的白色描边
            white_stroke_width = int(stroke_width * 1.3)  # 参考config.ini中的number_white_stroke_ratio
            white_stroke_color = (255, 255, 255, 255)
            shadow = True
            shadow_color = (0, 0, 0, 120)  # 参考config.ini中的shadow_color
            shadow_offset = (3, 3)  # 参考config.ini中的shadow_offset
        elif style == "style6":
            text_color = (220, 20, 60, 255)  # 红色，参考config.ini中的number_color
            stroke_color = (0, 0, 0, 255)  # 黑色描边，参考config.ini中的stroke_color
            stroke_width = 8  # 参考config.ini中的number_blue_stroke_px
            # 添加额外的白色描边
            white_stroke_width = int(stroke_width * 1.3)  # 参考config.ini中的number_white_stroke_ratio
            white_stroke_color = (255, 255, 255, 255)
            shadow = True
            shadow_color = (0, 0, 0, 150)  # 参考config.ini中的shadow_color
            shadow_offset = (4, 4)  # 参考config.ini中的shadow_offset
        else:
            text_color = (255, 255, 255, 255)  # 默认白色
            stroke_color = (0, 0, 0, 255)      # 黑色描边
            stroke_width = 3
            white_stroke_width = 4
            white_stroke_color = (255, 255, 255, 255)
            shadow = False
            shadow_offset = (0, 0)
        
        try:
            # 加载字体
            if font_path:
                font = ImageFont.truetype(str(font_path), font_size)
                print(f"成功加载字体 {font_path}，大小: {font_size}")
            else:
                font = ImageFont.load_default()
                print(f"使用默认字体，大小: {font_size}")
        except Exception as e:
            # 如果加载失败，使用默认字体
            print(f"加载字体失败: {e}，使用默认字体")
            font = ImageFont.load_default()
            font_size = 40  # 默认字体大小调整
        
        # 分割多行文本
        lines = text.strip().split('\n')
        
        # 计算文本总高度，设置行间距为10像素
        line_spacing = 10  # 行间距10像素
        line_height = font_size + line_spacing
        total_height = line_height * len(lines) - line_spacing  # 减去最后一行多余的行间距
        y_start = (height - total_height) // 2
        
        print(f"行数: {len(lines)}, 行高: {line_height}, 总高度: {total_height}, 起始Y: {y_start}")
        
        # 绘制每行文本
        for i, line in enumerate(lines):
            # 计算文本宽度以居中
            text_width = draw.textlength(line, font=font)
            x = (width - text_width) // 2
            y = y_start + i * line_height
            
            print(f"行 {i+1}: 宽度={text_width}, X={x}, Y={y}")
            
            # 绘制阴影（如果启用）
            if shadow:
                shadow_x = x + shadow_offset[0]
                shadow_y = y + shadow_offset[1]
                draw.text((shadow_x, shadow_y), line, font=font, fill=shadow_color)
            
            # 绘制白色外描边（如果有）
            if 'white_stroke_width' in locals() and white_stroke_width > 0:
                for offset_x in range(-white_stroke_width, white_stroke_width + 1):
                    for offset_y in range(-white_stroke_width, white_stroke_width + 1):
                        if offset_x == 0 and offset_y == 0:
                            continue
                        draw.text((x + offset_x, y + offset_y), line, font=font, fill=white_stroke_color)
            
            # 绘制主描边
            for offset_x in range(-stroke_width, stroke_width + 1):
                for offset_y in range(-stroke_width, stroke_width + 1):
                    if offset_x == 0 and offset_y == 0:
                        continue
                    draw.text((x + offset_x, y + offset_y), line, font=font, fill=stroke_color)
            
            # 绘制文本
            draw.text((x, y), line, font=font, fill=text_color)
        
        # 保存图片
        image.save(output_path, 'PNG')
        print(f"字幕图片已保存: {output_path}")
        return output_path
        
    except Exception as e:
        print(f"创建字幕图片失败: {e}")
        import traceback
        traceback.print_exc()
        return None
