#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
备份管理器GUI界面
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from backup_manager import BackupManager


class BackupManagerGUI:
    """备份管理器GUI类"""
    
    def __init__(self, root):
        """初始化GUI"""
        self.root = root
        self.root.title("代码备份管理器")
        self.root.geometry("700x500")
        self.root.minsize(700, 500)
        
        # 创建备份管理器
        self.manager = BackupManager()
        
        # 创建界面
        self.setup_ui()
        
        # 加载备份列表
        self.load_backups()
    
    def setup_ui(self):
        """设置界面"""
        # 主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 顶部操作区
        top_frame = ttk.Frame(main_frame)
        top_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 创建备份按钮
        create_btn = ttk.Button(top_frame, text="创建备份", command=self.create_backup)
        create_btn.pack(side=tk.LEFT, padx=5)
        
        # 恢复备份按钮
        restore_btn = ttk.Button(top_frame, text="恢复备份", command=self.restore_backup)
        restore_btn.pack(side=tk.LEFT, padx=5)
        
        # 删除备份按钮
        delete_btn = ttk.Button(top_frame, text="删除备份", command=self.delete_backup)
        delete_btn.pack(side=tk.LEFT, padx=5)
        
        # 刷新按钮
        refresh_btn = ttk.Button(top_frame, text="刷新列表", command=self.load_backups)
        refresh_btn.pack(side=tk.RIGHT, padx=5)
        
        # 备份列表
        list_frame = ttk.Frame(main_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建Treeview
        columns = ("id", "date", "description")
        self.backup_tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        
        # 设置列标题
        self.backup_tree.heading("id", text="备份ID")
        self.backup_tree.heading("date", text="创建时间")
        self.backup_tree.heading("description", text="描述")
        
        # 设置列宽
        self.backup_tree.column("id", width=150)
        self.backup_tree.column("date", width=150)
        self.backup_tree.column("description", width=350)
        
        # 添加滚动条
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.backup_tree.yview)
        self.backup_tree.configure(yscroll=scrollbar.set)
        
        # 放置Treeview和滚动条
        self.backup_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 双击事件
        self.backup_tree.bind("<Double-1>", self.on_backup_double_click)
        
        # 状态栏
        self.status_var = tk.StringVar()
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, anchor=tk.W)
        status_bar.pack(fill=tk.X, pady=(10, 0))
        
        self.status_var.set("就绪")
    
    def load_backups(self):
        """加载备份列表"""
        # 清空列表
        for item in self.backup_tree.get_children():
            self.backup_tree.delete(item)
        
        # 获取备份列表
        backups = self.manager.list_backups()
        
        # 按时间倒序排序
        backups.sort(key=lambda x: x["timestamp"], reverse=True)
        
        # 添加到列表
        for backup in backups:
            self.backup_tree.insert("", tk.END, values=(
                backup["id"],
                backup["date"],
                backup["description"]
            ))
        
        self.status_var.set(f"共 {len(backups)} 个备份")
    
    def create_backup(self):
        """创建备份"""
        # 弹出对话框询问描述
        description = simpledialog.askstring("创建备份", "请输入备份描述:", parent=self.root)
        if description is None:
            return  # 用户取消
        
        # 创建备份
        backup_id = self.manager.create_backup(description)
        if backup_id:
            messagebox.showinfo("成功", f"备份创建成功: {backup_id}")
            self.load_backups()
        else:
            messagebox.showerror("错误", "创建备份失败")
    
    def restore_backup(self):
        """恢复备份"""
        # 获取选中项
        selected = self.backup_tree.selection()
        if not selected:
            messagebox.showwarning("警告", "请先选择要恢复的备份")
            return
        
        # 获取备份ID
        backup_id = self.backup_tree.item(selected[0], "values")[0]
        
        # 确认
        if not messagebox.askyesno("确认", "恢复备份将覆盖当前代码，确定要继续吗？"):
            return
        
        # 恢复备份
        if self.manager.restore_backup(backup_id):
            messagebox.showinfo("成功", "备份恢复成功，请重启应用程序")
            self.root.quit()
        else:
            messagebox.showerror("错误", "恢复备份失败")
    
    def delete_backup(self):
        """删除备份"""
        # 获取选中项
        selected = self.backup_tree.selection()
        if not selected:
            messagebox.showwarning("警告", "请先选择要删除的备份")
            return
        
        # 获取备份ID
        backup_id = self.backup_tree.item(selected[0], "values")[0]
        
        # 确认
        if not messagebox.askyesno("确认", "确定要删除这个备份吗？"):
            return
        
        # 删除备份
        if self.manager.delete_backup(backup_id):
            messagebox.showinfo("成功", "备份已删除")
            self.load_backups()
        else:
            messagebox.showerror("错误", "删除备份失败")
    
    def on_backup_double_click(self, event):
        """双击备份项"""
        # 获取选中项
        selected = self.backup_tree.selection()
        if not selected:
            return
        
        # 获取备份信息
        values = self.backup_tree.item(selected[0], "values")
        backup_id = values[0]
        date = values[1]
        description = values[2]
        
        # 显示详细信息
        messagebox.showinfo("备份详情", f"ID: {backup_id}\n日期: {date}\n描述: {description}")


def main():
    """主函数"""
    root = tk.Tk()
    app = BackupManagerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main() 