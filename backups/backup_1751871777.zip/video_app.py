#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频处理应用程序统一入口
支持命令行模式和图形界面模式
"""

import os
import sys
import argparse
import traceback
from pathlib import Path

# 导入处理函数
from video_core import process_video, batch_process_videos
from utils import get_data_path, get_video_info, load_style_config

# 定义全局变量表示是否有GUI支持
HAS_PYQT5 = False
try:
    from PyQt5.QtWidgets import QApplication, QMessageBox
    from PyQt5.QtGui import QIcon
    HAS_PYQT5 = True
except ImportError:
    # PyQt5 未安装，但我们会在需要时处理这个问题
    pass

def parse_arguments():
    """解析命令行参数"""
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='视频处理工具')
    parser.add_argument('--video', help='要处理的视频文件路径')
    parser.add_argument('--output', help='输出视频文件路径')
    parser.add_argument('--style', help='字幕样式', choices=['style1', 'style2', 'style3', 'style4', 'style5', 'style6', 'style7', 'style8', 'style9', 'style10', 'style11', 'random'])
    parser.add_argument('--lang', help='字幕语言', choices=['malay', 'thai', 'random'])
    parser.add_argument('--batch', action='store_true', help='批量处理所有视频')
    parser.add_argument('--gui', action='store_true', help='启动图形界面')
    parser.add_argument('--quicktime', action='store_true', help='生成QuickTime兼容的视频')
    parser.add_argument('--debug', action='store_true', help='启用调试模式')
    parser.add_argument('--img-x', type=float, default=0.15, help='图片水平位置系数（视频宽度的百分比，默认0.15）')
    parser.add_argument('--img-y', type=int, default=120, help='图片垂直位置偏移（相对于背景位置，默认120像素向下偏移）')
    
    return parser.parse_args()

def show_pyqt5_missing_message():
    """显示PyQt5缺失的错误信息"""
    print("错误: 未找到PyQt5库")
    print("要启动图形界面，请先安装PyQt5:")
    print("pip install PyQt5")
    print("\n您仍可以使用命令行模式运行应用程序：")
    print("python video_app.py --video <视频文件路径>  # 处理单个视频")
    print("python video_app.py --batch                # 批量处理视频")
    sys.exit(1)

def start_gui():
    """启动PyQt5图形界面"""
    # 首先检查PyQt5是否已安装
    if not HAS_PYQT5:
        show_pyqt5_missing_message()
    
    try:
        # 检查其他依赖库
        required_packages = {
            "PIL": "pillow",    # 图像处理库
            "pandas": "pandas"  # 数据处理库
        }
        
        missing_packages = []
        for module, package in required_packages.items():
            try:
                __import__(module)
            except ImportError:
                missing_packages.append(package)
        
        # 如果有缺失的包，提示安装
        if missing_packages:
            print("以下依赖库未安装:")
            for package in missing_packages:
                print(f" - {package}")
            print("\n请运行以下命令安装:")
            print(f"pip install {' '.join(missing_packages)}")
            
            # 显示GUI错误消息
            try:
                app = QApplication(sys.argv)
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Critical)
                msg.setWindowTitle("缺少依赖")
                msg.setText("无法启动应用程序")
                msg.setInformativeText("缺少以下依赖库:\n" + "\n".join(f" - {p}" for p in missing_packages))
                msg.setDetailedText(f"请运行以下命令安装缺少的依赖:\npip install {' '.join(missing_packages)}")
                msg.exec_()
            except:
                pass
                
            sys.exit(1)
            
        # 导入自定义GUI模块
        try:
            # 从本地导入GUI类
            from video_app_gui import VideoProcessorApp
            
            # 创建应用程序
            app = QApplication(sys.argv)
            
            # 设置应用程序样式
            app.setStyle("Fusion")
            
            # 设置应用程序图标
            current_dir = os.path.dirname(os.path.abspath(__file__))
            icon_path = os.path.join(current_dir, "icon.png")
            if os.path.exists(icon_path):
                app.setWindowIcon(QIcon(icon_path))
            
            # 创建并显示主窗口
            window = VideoProcessorApp()
            window.show()
            
            # 运行应用程序
            sys.exit(app.exec_())
            
        except ImportError as e:
            error_message = f"错误: 无法导入GUI模块 - {e}"
            print(error_message)
            print("请确保video_app_gui.py在当前目录中")
            
            # 显示GUI错误消息
            try:
                app = QApplication(sys.argv)
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Critical)
                msg.setWindowTitle("导入错误")
                msg.setText("无法启动应用程序")
                msg.setInformativeText(error_message)
                msg.setDetailedText(traceback.format_exc())
                msg.exec_()
            except:
                pass
                
            sys.exit(1)
            
    except Exception as e:
        print(f"启动GUI时出错: {e}")
        traceback.print_exc()
        sys.exit(1)

def main():
    """主函数"""
    args = parse_arguments()
    
    # 如果没有指定具体模式，默认启动GUI
    if not (args.video or args.batch) or args.gui:
        if not HAS_PYQT5 and args.gui:
            show_pyqt5_missing_message()
        elif not HAS_PYQT5:
            print("未安装GUI界面库(PyQt5)，将使用命令行模式")
            print("使用 --help 查看可用选项")
            sys.exit(1)
        else:
            start_gui()
        return
    
    # 处理style和lang参数
    style = "random" if args.style == 'random' else (None if args.style is None else args.style)
    subtitle_lang = "random" if args.lang == 'random' else (None if args.lang is None else args.lang)
    
    # 批量处理模式
    if args.batch:
        print("开始批量处理视频...")
        success_count = batch_process_videos(
            style=style,  # 如果为None或"random"，每个视频随机选择样式
            subtitle_lang=subtitle_lang,  # 如果为None或"random"，每个视频随机选择语言
            quicktime_compatible=args.quicktime,
            img_position_x=args.img_x,
            img_position_y=args.img_y
        )
        print(f"批量处理完成: {success_count} 个视频成功处理")
        return
        
    # 单个视频处理模式
    if args.video:
        video_path = args.video
        output_path = args.output
        
        # 如果未指定输出路径，则生成一个
        if not output_path:
            video_name = os.path.basename(video_path)
            video_name_without_ext = os.path.splitext(video_name)[0]
            output_dir = get_data_path("output")
            output_path = os.path.join(output_dir, f"{video_name_without_ext}_processed.mp4")
        
        # 确保输出目录存在
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        print(f"处理视频: {video_path}")
        print(f"输出路径: {output_path}")
        print(f"样式: {style or '随机'}, 语言: {subtitle_lang or '随机'}")
        
        # 处理视频
        result = process_video(
            video_path, 
            output_path, 
            style=style,  # 如果为None，随机选择样式
            subtitle_lang=subtitle_lang,  # 如果为None，随机选择语言
            quicktime_compatible=args.quicktime,
            img_position_x=args.img_x,
            img_position_y=args.img_y
        )
        
        if result:
            print(f"✅ 视频处理成功: {output_path}")
        else:
            print(f"❌ 视频处理失败")
        
        return

if __name__ == "__main__":
    main()
