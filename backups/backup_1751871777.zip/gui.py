#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频处理工具图形界面
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import subprocess
from pathlib import Path
import threading

class VideoAppGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("视频处理工具")
        self.root.geometry("800x600")
        self.setup_ui()
        
    def setup_ui(self):
        # 主框架
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = ttk.Label(main_frame, text="视频处理工具", font=("Helvetica", 16, "bold"))
        title_label.pack(pady=(0, 20))
        
        # 输入/输出部分
        io_frame = ttk.LabelFrame(main_frame, text="输入/输出设置", padding=10)
        io_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 输入视频选择
        input_frame = ttk.Frame(io_frame)
        input_frame.pack(fill=tk.X, pady=5)
        ttk.Label(input_frame, text="输入视频:").pack(side=tk.LEFT)
        self.input_var = tk.StringVar()
        ttk.Entry(input_frame, textvariable=self.input_var).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(input_frame, text="浏览...", command=self.browse_input).pack(side=tk.RIGHT)
        
        # 输出目录选择
        output_frame = ttk.Frame(io_frame)
        output_frame.pack(fill=tk.X, pady=5)
        ttk.Label(output_frame, text="输出位置:").pack(side=tk.LEFT)
        self.output_var = tk.StringVar()
        ttk.Entry(output_frame, textvariable=self.output_var).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(output_frame, text="浏览...", command=self.browse_output).pack(side=tk.RIGHT)
        
        # 参数设置部分
        params_frame = ttk.LabelFrame(main_frame, text="参数设置", padding=10)
        params_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 样式选择
        style_frame = ttk.Frame(params_frame)
        style_frame.pack(fill=tk.X, pady=5)
        ttk.Label(style_frame, text="字幕样式:").pack(side=tk.LEFT)
        self.style_var = tk.StringVar(value="style1")
        style_combo = ttk.Combobox(style_frame, textvariable=self.style_var, 
                                 values=["style1", "style2", "style3", "style4", "style5", "style6"])
        style_combo.pack(side=tk.LEFT, padx=5)
        
        # 语言选择
        lang_frame = ttk.Frame(params_frame)
        lang_frame.pack(fill=tk.X, pady=5)
        ttk.Label(lang_frame, text="字幕语言:").pack(side=tk.LEFT)
        self.lang_var = tk.StringVar(value="malay")
        lang_combo = ttk.Combobox(lang_frame, textvariable=self.lang_var, values=["malay", "thai"])
        lang_combo.pack(side=tk.LEFT, padx=5)
        
        # QuickTime兼容选项
        quicktime_frame = ttk.Frame(params_frame)
        quicktime_frame.pack(fill=tk.X, pady=5)
        self.quicktime_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(quicktime_frame, text="生成QuickTime兼容视频", variable=self.quicktime_var).pack(side=tk.LEFT)
        
        # 图片位置设置
        img_pos_frame = ttk.LabelFrame(params_frame, text="图片位置设置", padding=10)
        img_pos_frame.pack(fill=tk.X, pady=(10, 5))
        
        # 水平位置
        img_x_frame = ttk.Frame(img_pos_frame)
        img_x_frame.pack(fill=tk.X, pady=5)
        ttk.Label(img_x_frame, text="水平位置系数 (0.0-1.0):").pack(side=tk.LEFT)
        self.img_x_var = tk.DoubleVar(value=0.15)
        ttk.Spinbox(img_x_frame, from_=0.0, to=1.0, increment=0.05, textvariable=self.img_x_var).pack(side=tk.LEFT, padx=5)
        
        # 垂直位置
        img_y_frame = ttk.Frame(img_pos_frame)
        img_y_frame.pack(fill=tk.X, pady=5)
        ttk.Label(img_y_frame, text="垂直位置偏移 (像素):").pack(side=tk.LEFT)
        self.img_y_var = tk.IntVar(value=-150)
        ttk.Spinbox(img_y_frame, from_=-500, to=500, increment=10, textvariable=self.img_y_var).pack(side=tk.LEFT, padx=5)
        
        # 批处理选项
        batch_frame = ttk.Frame(main_frame)
        batch_frame.pack(fill=tk.X, pady=10)
        self.batch_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(batch_frame, text="批量处理所有视频", variable=self.batch_var, 
                       command=self.toggle_batch_mode).pack(side=tk.LEFT)
        
        # 操作按钮
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        ttk.Button(button_frame, text="处理", command=self.process_video).pack(side=tk.RIGHT, padx=5)
        ttk.Button(button_frame, text="退出", command=self.root.destroy).pack(side=tk.RIGHT, padx=5)
        
        # 状态框
        self.status_var = tk.StringVar(value="就绪")
        status_frame = ttk.Frame(main_frame)
        status_frame.pack(fill=tk.X, pady=(10, 0))
        ttk.Label(status_frame, text="状态:").pack(side=tk.LEFT)
        ttk.Label(status_frame, textvariable=self.status_var).pack(side=tk.LEFT, padx=5)
        
        # 进度条
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate')
        self.progress.pack(fill=tk.X, pady=(10, 0))
        
    def browse_input(self):
        if self.batch_var.get():
            # 批处理模式选择目录
            directory = filedialog.askdirectory(title="选择视频目录")
            if directory:
                self.input_var.set(directory)
        else:
            # 单个处理模式选择文件
            filetypes = [("视频文件", "*.mp4 *.mov *.avi *.wmv *.mkv")]
            filename = filedialog.askopenfilename(title="选择视频文件", filetypes=filetypes)
            if filename:
                self.input_var.set(filename)
                
                # 自动设置输出目录
                output_dir = os.path.join(os.path.dirname(filename), "output")
                self.output_var.set(output_dir)
    
    def browse_output(self):
        directory = filedialog.askdirectory(title="选择输出目录")
        if directory:
            self.output_var.set(directory)
    
    def toggle_batch_mode(self):
        if self.batch_var.get():
            # 切换到批处理模式
            self.input_var.set("") # 清空输入
            messagebox.showinfo("批处理模式", "请选择包含视频文件的输入目录")
        else:
            # 切换到单文件模式
            self.input_var.set("") # 清空输入
    
    def process_video(self):
        # 获取参数
        input_path = self.input_var.get()
        output_path = self.output_var.get()
        style = self.style_var.get()
        lang = self.lang_var.get()
        quicktime = self.quicktime_var.get()
        img_x = self.img_x_var.get()
        img_y = self.img_y_var.get()
        batch_mode = self.batch_var.get()
        
        # 验证输入
        if not input_path:
            messagebox.showerror("错误", "请选择输入" + ("目录" if batch_mode else "视频文件"))
            return
        
        if not output_path:
            messagebox.showerror("错误", "请选择输出目录")
            return
        
        # 确保输出目录存在
        os.makedirs(output_path, exist_ok=True)
        
        # 构建命令
        cmd = [sys.executable]
        script_dir = os.path.dirname(os.path.abspath(__file__))
        video_app_path = os.path.join(script_dir, "video_app.py")
        cmd.append(video_app_path)
        
        if batch_mode:
            cmd.append("--batch")
        else:
            cmd.extend(["--video", input_path])
            cmd.extend(["--output", os.path.join(output_path, os.path.basename(input_path))])
        
        cmd.extend(["--style", style])
        cmd.extend(["--lang", lang])
        
        if quicktime:
            cmd.append("--quicktime")
        
        cmd.extend(["--img-x", str(img_x)])
        cmd.extend(["--img-y", str(img_y)])
        
        # 禁用界面
        self.disable_ui()
        
        # 启动进度条
        self.progress.start()
        
        # 在单独的线程中执行处理
        threading.Thread(target=self.run_process, args=(cmd,), daemon=True).start()
    
    def run_process(self, cmd):
        try:
            self.status_var.set("正在处理...")
            process = subprocess.Popen(cmd, 
                                     stdout=subprocess.PIPE, 
                                     stderr=subprocess.PIPE,
                                     text=True,
                                     universal_newlines=True)
            
            stdout, stderr = process.communicate()
            
            if process.returncode == 0:
                # 成功
                self.root.after(0, lambda: self.status_var.set("处理完成"))
                self.root.after(0, lambda: messagebox.showinfo("完成", "视频处理完成!"))
            else:
                # 失败
                error_msg = stderr or stdout or "未知错误"
                self.root.after(0, lambda: self.status_var.set("处理失败"))
                self.root.after(0, lambda: messagebox.showerror("错误", f"处理失败: {error_msg}"))
        except Exception as e:
            # 异常
            self.root.after(0, lambda: self.status_var.set("处理出错"))
            self.root.after(0, lambda: messagebox.showerror("错误", f"发生异常: {str(e)}"))
        finally:
            # 停止进度条并启用界面
            self.root.after(0, self.enable_ui)
    
    def disable_ui(self):
        """禁用界面元素"""
        for child in self.root.winfo_children():
            self.disable_widget(child)
    
    def enable_ui(self):
        """启用界面元素"""
        self.progress.stop()
        for child in self.root.winfo_children():
            self.enable_widget(child)
    
    def disable_widget(self, widget):
        """递归禁用所有小部件"""
        try:
            widget.configure(state="disabled")
        except:
            pass
        
        for child in widget.winfo_children():
            self.disable_widget(child)
    
    def enable_widget(self, widget):
        """递归启用所有小部件"""
        try:
            widget.configure(state="normal")
        except:
            pass
        
        for child in widget.winfo_children():
            self.enable_widget(child)

def main():
    root = tk.Tk()
    app = VideoAppGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
