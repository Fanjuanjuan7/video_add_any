#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工具函数模块 - 提供基础工具函数支持
包含文件操作、路径处理、配置加载等功能
"""

import os
import sys
import pandas as pd
import subprocess
import shutil
from pathlib import Path
import time
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import ast


# 路径相关函数
def get_app_path():
    """
    获取应用程序根目录的绝对路径
    支持直接运行和打包成App后运行
    """
    if getattr(sys, 'frozen', False):
        # 如果应用被打包
        if hasattr(sys, '_MEIPASS'):
            # PyInstaller
            return Path(sys._MEIPASS)
        else:
            # py2app或其他
            return Path(os.path.dirname(os.path.dirname(sys.executable)))
    else:
        # 普通Python脚本
        return Path(os.path.dirname(os.path.abspath(__file__)))


def get_data_path(sub_dir=""):
    """
    获取数据目录路径
    
    参数:
        sub_dir: 子目录，如 "input/videos"
    
    返回:
        data目录下指定子目录的路径
    """
    data_path = get_app_path() / "data"
    
    # 如果sub_dir为空，确保data目录存在
    if not sub_dir:
        os.makedirs(data_path, exist_ok=True)
        return data_path
    
    # 分离路径和可能的文件名
    parts = Path(sub_dir).parts
    if '.' in parts[-1]:  # 最后一部分包含点，可能是文件
        dir_path = data_path.joinpath(*parts[:-1])  # 目录部分
        full_path = data_path / sub_dir  # 完整路径（包括可能的文件）
        
        # 只确保目录存在
        os.makedirs(dir_path, exist_ok=True)
        return full_path
    else:
        # 是纯目录路径
        full_path = data_path / sub_dir
        os.makedirs(full_path, exist_ok=True)
        return full_path


# 配置文件处理
def load_subtitle_config():
    """
    加载字幕配置文件(subtitle.csv)
    
    返回:
        pandas.DataFrame: 包含name、title、style等列的DataFrame
    """
    config_path = get_data_path("config") / "subtitle.csv"
    
    if not config_path.exists():
        # 如果配置文件不存在，创建一个空的
        df = pd.DataFrame(columns=["name", "title", "title_thai", "style"])
        df.to_csv(config_path, index=False, encoding="utf-8")
        print(f"创建了新的配置文件: {config_path}")
        return df
    
    try:
        # 尝试读取配置文件，确保使用UTF-8编码
        df = pd.read_csv(config_path, encoding="utf-8")
        print(f"成功加载配置: {config_path}")
        
        # 确保必要的列存在
        required_columns = ["name", "title", "style"]
        for col in required_columns:
            if col not in df.columns:
                df[col] = ""
        
        # 确保title_thai列存在
        if "title_thai" not in df.columns:
            df["title_thai"] = ""
                
        return df
    except UnicodeDecodeError:
        # 如果UTF-8解码失败，尝试其他编码
        try:
            df = pd.read_csv(config_path, encoding="ISO-8859-1")
            # 将数据转换为UTF-8
            df.to_csv(config_path, index=False, encoding="utf-8")
            print(f"配置文件已从其他编码转换为UTF-8: {config_path}")
            return df
        except Exception as e:
            print(f"读取配置文件失败(尝试其他编码): {e}")
            return pd.DataFrame(columns=["name", "title", "title_thai", "style"])
    except Exception as e:
        print(f"读取配置文件失败: {e}")
        # 返回一个空的DataFrame
        return pd.DataFrame(columns=["name", "title", "title_thai", "style"])


def load_style_config(style=None):
    """
    加载样式配置文件(subtitle_styles.ini)
    
    参数:
        style: 样式名称，如果提供则返回特定样式的配置，否则返回整个配置对象
        
    返回:
        如果提供了style，返回该样式的配置字典；否则返回整个ConfigParser对象
    """
    import configparser
    
    # 尝试不同位置查找配置文件
    config_paths = [
        get_data_path("config") / "subtitle_styles.ini",
        Path("VideoApp/config") / "subtitle_styles.ini",
        Path("config") / "subtitle_styles.ini",
        Path(os.getcwd()) / "config" / "subtitle_styles.ini"
    ]
    
    config = configparser.ConfigParser()
    
    # 尝试读取配置文件
    config_found = False
    for config_path in config_paths:
        if config_path.exists():
            try:
                config.read(str(config_path), encoding='utf-8')
                print(f"成功加载样式配置: {config_path}")
                config_found = True
                break
            except Exception as e:
                print(f"读取样式配置文件 {config_path} 失败: {e}")
    
    if not config_found:
        print("未找到样式配置文件，将使用默认样式")
        return {} if style else config
    
    # 如果提供了style参数，返回该样式的配置
    if style:
        style_section = f"styles.{style}"
        if config.has_section(style_section):
            # 将配置项转换为字典
            style_dict = {}
            for key, value in config.items(style_section):
                # 尝试解析列表类型的值
                if key in ['text_color', 'stroke_color', 'shadow_color', 'shadow_offset']:
                    try:
                        style_dict[key] = ast.literal_eval(value)
                    except:
                        style_dict[key] = value
                # 尝试解析数值类型的值
                elif key in ['font_size', 'stroke_width', 'white_stroke_ratio']:
                    try:
                        if '.' in value:
                            style_dict[key] = float(value)
                        else:
                            style_dict[key] = int(value)
                    except:
                        style_dict[key] = value
                # 尝试解析布尔类型的值
                elif key == 'shadow':
                    style_dict[key] = value.lower() in ['true', 'yes', '1']
                else:
                    style_dict[key] = value
            
            return style_dict
        else:
            print(f"样式 {style} 在配置文件中不存在，将使用默认样式")
            return {}
    
    return config


# 文件操作
def find_matching_file(base_name, directory, extensions=[".jpg", ".png", ".jpeg"]):
    """
    在指定目录中查找与base_name匹配的文件
    
    参数:
        base_name: 文件名基础部分(不含扩展名)
        directory: 要搜索的目录
        extensions: 要匹配的文件扩展名列表
    
    返回:
        找到的文件路径，如果没找到则返回None
    """
    directory_path = Path(directory)
    if not directory_path.exists():
        return None
    
    # 首先尝试完全匹配
    for ext in extensions:
        file_path = directory_path / f"{base_name}{ext}"
        if file_path.exists():
            return file_path
    
    # 如果没有完全匹配，尝试部分匹配
    for file in os.listdir(directory_path):
        file_base = os.path.splitext(file)[0].lower()
        if base_name.lower() in file_base or file_base in base_name.lower():
            file_path = directory_path / file
            if file_path.suffix.lower() in [ext.lower() for ext in extensions]:
                return file_path
    
    return None


# FFMPEG命令执行
def run_ffmpeg_command(command, quiet=False):
    """
    执行FFMPEG命令
    
    参数:
        command: 命令列表，如 ["ffmpeg", "-i", "input.mp4", "output.mp4"]
        quiet: 是否静默执行
    
    返回:
        成功返回True，失败返回False
    """
    if not quiet:
        print(f"执行命令: {' '.join(command)}")
    
    try:
        if quiet:
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            result = subprocess.run(command)
            
        return result.returncode == 0
    except Exception as e:
        print(f"执行命令失败: {e}")
        return False


def get_video_info(video_path):
    """
    获取视频信息(宽度、高度、时长)
    
    参数:
        video_path: 视频文件路径
    
    返回:
        (width, height, duration) 元组，失败返回None
    """
    try:
        # 获取视频尺寸
        size_cmd = [
            "ffprobe", "-v", "error", "-select_streams", "v:0",
            "-show_entries", "stream=width,height", "-of", "csv=s=x:p=0",
            str(video_path)
        ]
        video_size = subprocess.check_output(size_cmd).decode("utf-8").strip()
        width, height = map(int, video_size.split("x"))
        
        # 获取视频时长
        duration_cmd = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)
        ]
        duration_str = subprocess.check_output(duration_cmd).decode("utf-8").strip()
        
        # 确保获取到有效的时长值
        try:
            duration = float(duration_str)
            if duration <= 0.1:  # 如果时长异常短，尝试使用另一种方法
                print(f"警告: 检测到异常短的视频时长 ({duration}秒)，尝试使用另一种方法获取...")
                # 使用另一种方法获取时长
                alt_duration_cmd = [
                    "ffprobe", "-v", "error", "-select_streams", "v:0",
                    "-show_entries", "stream=duration", "-of", "default=noprint_wrappers=1:nokey=1",
                    str(video_path)
                ]
                alt_duration_str = subprocess.check_output(alt_duration_cmd).decode("utf-8").strip()
                if alt_duration_str and float(alt_duration_str) > 0.1:
                    duration = float(alt_duration_str)
                    print(f"使用流时长: {duration}秒")
                else:
                    # 如果流时长也不可用，使用帧数和帧率计算
                    frame_cmd = [
                        "ffprobe", "-v", "error", "-count_frames",
                        "-select_streams", "v:0", "-show_entries", "stream=nb_read_frames",
                        "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)
                    ]
                    fps_cmd = [
                        "ffprobe", "-v", "error", "-select_streams", "v:0",
                        "-show_entries", "stream=r_frame_rate", "-of", "default=noprint_wrappers=1:nokey=1",
                        str(video_path)
                    ]
                    
                    try:
                        frames = int(subprocess.check_output(frame_cmd).decode("utf-8").strip())
                        fps_str = subprocess.check_output(fps_cmd).decode("utf-8").strip()
                        fps_parts = fps_str.split('/')
                        if len(fps_parts) == 2:
                            fps = float(fps_parts[0]) / float(fps_parts[1])
                        else:
                            fps = float(fps_str)
                        
                        if frames > 0 and fps > 0:
                            duration = frames / fps
                            print(f"使用帧数计算时长: {frames}帧 / {fps}fps = {duration}秒")
                    except Exception as e:
                        print(f"帧数计算失败: {e}")
                        # 使用默认值
                        duration = 10.0
                        print(f"无法获取准确时长，使用默认值: {duration}秒")
        except ValueError:
            print(f"无法解析时长字符串: '{duration_str}'")
            duration = 10.0  # 使用默认值
            
        print(f"视频信息: {width}x{height}, {duration}秒")
        return width, height, duration
    except Exception as e:
        print(f"获取视频信息失败: {e}")
        # 返回默认值
        return 1080, 1920, 10.0  # 默认值


def ensure_dir(directory):
    """确保目录存在，不存在则创建"""
    os.makedirs(directory, exist_ok=True)


def find_font_file(font_path):
    """
    查找字体文件
    
    参数:
        font_path: 字体路径，可以是相对路径或绝对路径
        
    返回:
        找到的字体文件路径，如果没找到则返回None
    """
    # 如果是绝对路径且文件存在，直接返回
    if os.path.isabs(font_path) and os.path.exists(font_path):
        return font_path
    
    # 尝试不同的基础路径
    possible_paths = [
        font_path,  # 原始路径
        os.path.join(get_app_path(), font_path),  # 相对于应用程序路径
        os.path.join(os.getcwd(), font_path),  # 相对于当前工作目录
        os.path.join(get_data_path(), font_path),  # 相对于数据目录
        os.path.join(get_app_path(), "VideoApp", font_path),  # VideoApp子目录
        os.path.join(os.getcwd(), "VideoApp", font_path),  # 当前目录下的VideoApp子目录
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", font_path),  # 相对于utils.py的上级目录
        os.path.join(os.path.dirname(os.path.abspath(__file__)), font_path),  # 相对于utils.py目录
    ]
    
    # 检查可能的路径
    for path in possible_paths:
        if os.path.exists(path):
            print(f"找到字体文件: {path}")
            return path
    
    # 如果指定的字体文件找不到，尝试在fonts目录中查找任何可用的字体
    fonts_dirs = [
        os.path.join(get_data_path(), "fonts"),
        os.path.join(get_data_path(), "fonts/new"),  # 新增字体目录
        os.path.join(get_app_path(), "data/fonts"),
        os.path.join(get_app_path(), "data/fonts/new"),  # 新增字体目录
        os.path.join(os.getcwd(), "data/fonts"),
        os.path.join(os.getcwd(), "data/fonts/new"),  # 新增字体目录
        os.path.join(os.getcwd(), "VideoApp/data/fonts"),
        os.path.join(os.getcwd(), "VideoApp/data/fonts/new"),  # 新增字体目录
    ]
    
    # 获取字体文件名（不含路径）
    font_filename = os.path.basename(font_path)
    
    # 在fonts目录中查找匹配的字体
    for fonts_dir in fonts_dirs:
        if os.path.exists(fonts_dir):
            print(f"检查字体目录: {fonts_dir}")
            # 首先尝试精确匹配
            exact_match = os.path.join(fonts_dir, font_filename)
            if os.path.exists(exact_match):
                print(f"找到精确匹配的字体文件: {exact_match}")
                return exact_match
                
            # 如果没有精确匹配，尝试查找任何可用的字体
            try:
                font_files = [f for f in os.listdir(fonts_dir) if f.lower().endswith(('.ttf', '.otf'))]
                if font_files:
                    # 优先选择名称中包含Bold的字体
                    bold_fonts = [f for f in font_files if 'bold' in f.lower()]
                    if bold_fonts:
                        selected_font = os.path.join(fonts_dir, bold_fonts[0])
                        print(f"找不到指定字体，使用粗体字体: {selected_font}")
                        return selected_font
                    
                    # 如果没有粗体字体，使用任何可用字体
                    selected_font = os.path.join(fonts_dir, font_files[0])
                    print(f"找不到指定字体，使用可用字体: {selected_font}")
                    return selected_font
            except Exception as e:
                print(f"在字体目录中查找字体时出错: {e}")
    
    print(f"找不到字体文件: {font_path}")
    return None


# 字幕生成函数
def create_subtitle_image(text, style="style1", width=1080, height=300, font_size=30, output_path=None):
    """
    创建字幕图片
    
    参数:
        text: 字幕文本
        style: 样式名称
        width: 图片宽度
        height: 图片高度
        font_size: 字体大小
        output_path: 输出路径
        
    返回:
        字幕图片路径
    """
    try:
        print(f"创建字幕图片: 宽={width}, 高={height}, 字体大小={font_size}, 样式={style}")
        print(f"字幕内容: {text}")
        
        # 检查是否包含泰文
        def contains_thai(s):
            # 泰文Unicode范围: 0E00-0E7F
            for char in s:
                if '\u0E00' <= char <= '\u0E7F':
                    return True
            return False
            
        is_thai_text = contains_thai(text)
        print(f"是否包含泰文: {is_thai_text}")
        
        # 如果没有指定输出路径，生成一个临时文件
        if not output_path:
            import tempfile
            output_path = os.path.join(tempfile.gettempdir(), f"subtitle_{int(time.time())}.png")
            
        # 创建透明背景的图片
        image = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        
        # 加载样式配置
        style_config = load_style_config(style)
        if style_config:
            print(f"成功加载样式配置: {style_config}")
            
            # 获取字体路径
            font_path = style_config.get('font_path', 'data/fonts/BebasNeue-Regular.ttf')
            print(f"使用自定义字体路径: {font_path}")
            
            # 获取字体大小
            custom_font_size = style_config.get('font_size', font_size)
            print(f"使用自定义字体大小: {custom_font_size}")
            
            # 获取文本颜色
            text_color = style_config.get('text_color', [255, 255, 255, 255])
            if isinstance(text_color, list):
                text_color = tuple(text_color)  # 转换列表为元组
            print(f"使用自定义文本颜色: {text_color}")
            
            # 获取描边颜色
            stroke_color = style_config.get('stroke_color', [0, 0, 0, 255])
            if isinstance(stroke_color, list):
                stroke_color = tuple(stroke_color)  # 转换列表为元组
            print(f"使用自定义描边颜色: {stroke_color}")
            
            # 获取描边宽度
            stroke_width = style_config.get('stroke_width', 2)
            print(f"使用自定义描边宽度: {stroke_width}")
            
            # 获取白色描边比例
            white_stroke_ratio = style_config.get('white_stroke_ratio', 1.2)
            print(f"使用自定义白色描边比例: {white_stroke_ratio}")
            
            # 获取阴影设置
            shadow = style_config.get('shadow', False)
            shadow_color = style_config.get('shadow_color', [0, 0, 0, 120])
            if isinstance(shadow_color, list):
                shadow_color = tuple(shadow_color)  # 转换列表为元组
            shadow_offset = style_config.get('shadow_offset', [4, 4])
            print(f"使用自定义阴影设置: {shadow}")
            print(f"使用自定义阴影颜色: {shadow_color}")
            print(f"使用自定义阴影偏移: {shadow_offset}")
        else:
            # 默认样式
            font_path = 'data/fonts/BebasNeue-Regular.ttf'
            custom_font_size = font_size
            text_color = (255, 255, 255, 255)
            stroke_color = (0, 0, 0, 255)
            stroke_width = 2
            white_stroke_ratio = 1.2
            shadow = False
            shadow_color = (0, 0, 0, 120)
            shadow_offset = (4, 4)
            
        # 根据文本内容选择合适的字体
        if is_thai_text:
            # 如果是泰文，尝试使用泰文字体
            font_config = load_style_config()
            if font_config and 'font_paths' in font_config and 'thai' in font_config['font_paths']:
                thai_font_path = font_config['font_paths']['thai']
                font_file = find_font_file(thai_font_path)
                if font_file:
                    font_path = font_file
                    print(f"检测到泰文，使用泰文字体: {font_path}")
        
        # 查找字体文件
        font = None
        font_file = find_font_file(font_path)
        if font_file:
            print(f"找到字体文件: {font_file}")
            try:
                # 加载字体
                font = ImageFont.truetype(font_file, custom_font_size)
                print(f"成功加载字体 {font_file}，大小: {custom_font_size}")
            except Exception as e:
                print(f"加载字体失败: {e}")
                font = None
        
        # 如果字体加载失败，尝试加载其他字体
        if font is None:
            # 尝试其他可能的字体
            fallback_fonts = [
                "data/fonts/Kanit-Bold.ttf",
                "data/fonts/Sarabun-Bold.ttf",
                "data/fonts/Montserrat-Bold.ttf",
                "data/fonts/BebasNeue-Regular.ttf",
                "data/fonts/Arial.ttf",
                "Arial",
                "Helvetica",
                "DejaVuSans.ttf"
            ]
            
            for fb_font in fallback_fonts:
                try:
                    fb_font_file = find_font_file(fb_font)
                    if fb_font_file:
                        font = ImageFont.truetype(fb_font_file, custom_font_size)
                        print(f"使用备用字体: {fb_font_file}")
                        break
                    elif os.path.exists(fb_font):
                        font = ImageFont.truetype(fb_font, custom_font_size)
                        print(f"使用备用字体: {fb_font}")
                        break
                    elif fb_font in ["Arial", "Helvetica"]:
                        # 尝试使用系统字体
                        font = ImageFont.truetype(fb_font, custom_font_size)
                        print(f"使用系统字体: {fb_font}")
                        break
                except Exception as e:
                    print(f"加载备用字体 {fb_font} 失败: {e}")
                    continue
            
            # 如果所有字体都加载失败，使用默认字体
            if font is None:
                font = ImageFont.load_default()
                print("所有字体加载失败，使用默认字体")
                # 调整默认字体大小
                custom_font_size = min(custom_font_size, 40)  # 默认字体通常较小
        
        # 分割文本为多行
        lines = text.strip().split('\n')
        print(f"行数: {len(lines)}")
        
        # 计算行高和总高度
        line_height = int(custom_font_size * 1.1)  # 行高为字体大小的1.1倍
        total_height = line_height * len(lines)
        
        # 计算起始Y坐标，使文本垂直居中
        y_start = (height - total_height) // 2
        
        print(f"行高: {line_height}, 总高度: {total_height}, 起始Y: {y_start}")
        
        # 绘制每行文本
        for i, line in enumerate(lines):
            # 计算文本宽度以居中
            try:
                text_width = draw.textlength(line, font=font)
            except:
                # 对于旧版PIL，使用getsize
                try:
                    text_width, _ = font.getsize(line)
                except:
                    text_width = width // 2  # 如果无法获取宽度，使用默认值
            
            x = (width - text_width) // 2
            y = y_start + i * line_height
            
            print(f"行 {i+1}: 宽度={text_width}, X={x}, Y={y}")
            
            # 绘制阴影（如果启用）
            if shadow:
                shadow_x = x + shadow_offset[0]
                shadow_y = y + shadow_offset[1]
                draw.text((shadow_x, shadow_y), line, font=font, fill=shadow_color)
            
            # 描边方法1：使用多次绘制实现描边效果
            for dx in range(-stroke_width, stroke_width + 1):
                for dy in range(-stroke_width, stroke_width + 1):
                    if dx*dx + dy*dy <= stroke_width*stroke_width:  # 圆形描边
                        draw.text((x + dx, y + dy), line, font=font, fill=stroke_color)
            
            # 绘制主文本
            draw.text((x, y), line, font=font, fill=text_color)
        
        # 保存图片
        image.save(output_path)
        print(f"字幕图片已保存: {output_path}")
        
        return output_path
    except Exception as e:
        print(f"创建字幕图片失败: {e}")
        import traceback
        traceback.print_exc()
        return None
