#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频处理GUI界面
集成单个视频处理和批量处理功能
"""

import os
import sys
import json
import configparser
import subprocess  # 添加subprocess导入
from pathlib import Path

# 将所有PyQt5导入放在一个try块中
try:
    from PyQt5.QtWidgets import (QApplication, QMainWindow, QTabWidget, QWidget, QLabel, 
                                QLineEdit, QPushButton, QFileDialog, QComboBox, QCheckBox, 
                                QSpinBox, QDoubleSpinBox, QVBoxLayout, QHBoxLayout, QGridLayout, 
                                QGroupBox, QMessageBox, QProgressBar, QRadioButton, QButtonGroup,
                                QListWidget, QListWidgetItem, QAbstractItemView, QSplitter)
    from PyQt5.QtCore import Qt, QThread, pyqtSignal, QSettings
    from PyQt5.QtGui import QFont, QIcon, QPixmap
except ImportError as e:
    print(f"错误: {e}")
    print("缺少PyQt5库，请先安装:")
    print("pip install PyQt5")
    sys.exit(1)

# 确认必要的库导入
try:
    # 导入处理函数
    from video_core import process_video, batch_process_videos
    from utils import load_style_config, get_data_path
except ImportError as e:
    print(f"错误: {e}")
    print("请确保video_core.py和utils.py在当前目录或Python路径中")
    sys.exit(1)


class ProcessingThread(QThread):
    """视频处理线程"""
    progress_updated = pyqtSignal(int, str)
    processing_complete = pyqtSignal(bool, str)
    
    def __init__(self, video_paths, output_dir, style, subtitle_lang, 
                 quicktime_compatible, img_position_x, img_position_y, 
                 font_size, subtitle_x, subtitle_y, bg_width, bg_height, img_size,
                 subtitle_text_x, subtitle_text_y):
        super().__init__()
        self.video_paths = video_paths
        self.output_dir = output_dir
        self.style = style
        self.subtitle_lang = subtitle_lang
        self.quicktime_compatible = quicktime_compatible
        self.img_position_x = img_position_x
        self.img_position_y = img_position_y
        self.font_size = font_size
        self.subtitle_x = subtitle_x
        self.subtitle_y = subtitle_y
        self.bg_width = bg_width
        self.bg_height = bg_height
        self.img_size = img_size
        self.subtitle_text_x = subtitle_text_x
        self.subtitle_text_y = subtitle_text_y
    
    def run(self):
        try:
            total_videos = len(self.video_paths)
            success_count = 0
            
            for i, video_path in enumerate(self.video_paths):
                self.progress_updated.emit(int((i / total_videos) * 100), f"处理视频 {i+1}/{total_videos}: {Path(video_path).name}")
                
                output_path = Path(self.output_dir) / f"{Path(video_path).stem}_processed.mp4"
                
                result = process_video(
                    video_path, 
                    str(output_path),  # 确保路径是字符串
                    self.style, 
                    self.subtitle_lang, 
                    self.quicktime_compatible,
                    self.img_position_x, 
                    self.img_position_y,
                    self.font_size,
                    self.subtitle_x,
                    self.subtitle_y,
                    self.bg_width,
                    self.bg_height,
                    self.img_size,
                    self.subtitle_text_x,
                    self.subtitle_text_y
                )
                
                if result:
                    success_count += 1
            
            self.progress_updated.emit(100, f"完成! 成功处理 {success_count}/{total_videos} 个视频")
            self.processing_complete.emit(True, f"处理完成，成功: {success_count}/{total_videos}")
                
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.progress_updated.emit(100, f"处理出错: {str(e)}")
            self.processing_complete.emit(False, f"处理错误: {str(e)}")


class VideoProcessorApp(QMainWindow):
    """视频处理应用主窗口"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("视频处理工具")
        self.setGeometry(100, 100, 900, 700)
        
        # 加载配置和样式
        self.style_config = load_style_config()
        self.settings = QSettings("VideoApp", "VideoProcessor")
        
        # 初始化UI
        self.init_ui()
        self.load_saved_settings()
    
    def init_ui(self):
        """初始化用户界面"""
        # 创建主布局和标签页
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)
        
        # 创建标签页控件
        self.tabs = QTabWidget()
        self.process_tab = QWidget()
        self.settings_tab = QWidget()
        
        self.tabs.addTab(self.process_tab, "视频处理")
        self.tabs.addTab(self.settings_tab, "设置")
        
        # 初始化各个标签页
        self.init_process_tab()
        self.init_settings_tab()
        
        # 状态栏和进度条
        self.status_bar = self.statusBar()
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setTextVisible(True)
        self.status_bar.addPermanentWidget(self.progress_bar)
        self.status_bar.showMessage("准备就绪")
        
        # 添加标签页到主布局
        self.main_layout.addWidget(self.tabs)
        
    def init_process_tab(self):
        """初始化视频处理标签页"""
        main_layout = QVBoxLayout(self.process_tab)
        
        # 创建左右分栏
        splitter = QSplitter(Qt.Horizontal)
        
        # 左侧：视频选择和基本设置
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        
        # 视频选择组
        video_group = QGroupBox("视频选择")
        video_layout = QVBoxLayout()
        
        # 添加视频文件按钮
        video_btn_layout = QHBoxLayout()
        add_video_btn = QPushButton("添加视频文件")
        add_video_btn.clicked.connect(self.add_video_files)
        add_folder_btn = QPushButton("添加文件夹")
        add_folder_btn.clicked.connect(self.add_video_folder)
        clear_btn = QPushButton("清空列表")
        clear_btn.clicked.connect(self.clear_video_list)
        
        video_btn_layout.addWidget(add_video_btn)
        video_btn_layout.addWidget(add_folder_btn)
        video_btn_layout.addWidget(clear_btn)
        
        # 视频列表
        self.video_list = QListWidget()
        self.video_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.video_list.setMinimumHeight(200)
        
        video_layout.addLayout(video_btn_layout)
        video_layout.addWidget(QLabel("已选择的视频文件:"))
        video_layout.addWidget(self.video_list)
        
        video_group.setLayout(video_layout)
        
        # 输出设置组
        output_group = QGroupBox("输出设置")
        output_layout = QGridLayout()
        
        self.output_dir = QLineEdit()
        self.output_dir.setReadOnly(True)
        output_browse_btn = QPushButton("选择...")
        output_browse_btn.clicked.connect(self.browse_output_dir)
        
        output_layout.addWidget(QLabel("输出目录:"), 0, 0)
        output_layout.addWidget(self.output_dir, 0, 1)
        output_layout.addWidget(output_browse_btn, 0, 2)
        
        output_group.setLayout(output_layout)
        
        # 添加组件到左侧布局
        left_layout.addWidget(video_group)
        left_layout.addWidget(output_group)
        
        # 右侧：样式和高级设置
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        
        # 样式设置组
        style_group = QGroupBox("字幕样式")
        style_layout = QGridLayout()
        
        self.style_combo = QComboBox()
        self.populate_style_combo(self.style_combo)
        
        self.lang_combo = QComboBox()
        self.lang_combo.addItem("随机", "random")
        self.lang_combo.addItem("马来语", "malay")
        self.lang_combo.addItem("泰语", "thai")
        
        self.quicktime_check = QCheckBox("QuickTime兼容模式")
        
        # 添加字体大小调节
        self.font_size = QSpinBox()
        self.font_size.setRange(30, 150)
        self.font_size.setValue(70)
        self.font_size.setToolTip("字体大小（像素）")
        
        style_layout.addWidget(QLabel("字幕样式:"), 0, 0)
        style_layout.addWidget(self.style_combo, 0, 1)
        style_layout.addWidget(QLabel("字幕语言:"), 1, 0)
        style_layout.addWidget(self.lang_combo, 1, 1)
        style_layout.addWidget(QLabel("字体大小:"), 2, 0)
        style_layout.addWidget(self.font_size, 2, 1)
        style_layout.addWidget(self.quicktime_check, 3, 0, 1, 2)
        
        style_group.setLayout(style_layout)
        
        # 图片设置组
        img_group = QGroupBox("图片设置")
        img_layout = QGridLayout()
        
        self.img_x = QSpinBox()
        self.img_x.setRange(-9999, 9999)
        self.img_x.setValue(100)
        self.img_x.setToolTip("图片X轴绝对坐标（像素）")
        
        self.img_y = QSpinBox()
        self.img_y.setRange(-9999, 9999)
        self.img_y.setValue(1280)
        self.img_y.setToolTip("图片Y轴绝对坐标（像素）")
        
        self.img_size = QSpinBox()
        self.img_size.setRange(50, 1500)
        self.img_size.setValue(420)
        self.img_size.setSingleStep(10)
        self.img_size.setToolTip("图片大小（像素）")
        
        img_layout.addWidget(QLabel("X轴坐标 (像素):"), 0, 0)
        img_layout.addWidget(self.img_x, 0, 1)
        img_layout.addWidget(QLabel("Y轴坐标 (像素):"), 1, 0)
        img_layout.addWidget(self.img_y, 1, 1)
        img_layout.addWidget(QLabel("图片大小 (像素):"), 2, 0)
        img_layout.addWidget(self.img_size, 2, 1)
        
        img_group.setLayout(img_layout)
        
        # 位置设置组
        subtitle_pos_group = QGroupBox("位置设置")
        subtitle_pos_layout = QGridLayout()
        
        self.subtitle_x = QSpinBox()
        self.subtitle_x.setRange(-9999, 9999)
        self.subtitle_x.setValue(-50)
        self.subtitle_x.setToolTip("背景X轴绝对坐标（像素）")
        
        self.subtitle_y = QSpinBox()
        self.subtitle_y.setRange(-9999, 9999)
        self.subtitle_y.setValue(1100)
        self.subtitle_y.setToolTip("背景Y轴绝对坐标（像素）")
        
        self.subtitle_text_x = QSpinBox()
        self.subtitle_text_x.setRange(-9999, 9999)
        self.subtitle_text_x.setValue(0)
        self.subtitle_text_x.setToolTip("字幕X轴绝对坐标（像素）")
        
        self.subtitle_text_y = QSpinBox()
        self.subtitle_text_y.setRange(-9999, 9999)
        self.subtitle_text_y.setValue(1190)
        self.subtitle_text_y.setToolTip("字幕Y轴绝对坐标（像素）")
        
        subtitle_pos_layout.addWidget(QLabel("背景X轴坐标 (像素):"), 0, 0)
        subtitle_pos_layout.addWidget(self.subtitle_x, 0, 1)
        subtitle_pos_layout.addWidget(QLabel("背景Y轴坐标 (像素):"), 1, 0)
        subtitle_pos_layout.addWidget(self.subtitle_y, 1, 1)
        subtitle_pos_layout.addWidget(QLabel("字幕X轴坐标 (像素):"), 2, 0)
        subtitle_pos_layout.addWidget(self.subtitle_text_x, 2, 1)
        subtitle_pos_layout.addWidget(QLabel("字幕Y轴坐标 (像素):"), 3, 0)
        subtitle_pos_layout.addWidget(self.subtitle_text_y, 3, 1)
        
        subtitle_pos_group.setLayout(subtitle_pos_layout)
        
        # 背景设置组
        bg_group = QGroupBox("背景设置")
        bg_layout = QGridLayout()
        
        self.bg_width = QSpinBox()
        self.bg_width.setRange(500, 1500)
        self.bg_width.setValue(1000)
        self.bg_width.setSingleStep(50)
        self.bg_width.setToolTip("背景宽度（像素）")
        
        self.bg_height = QSpinBox()
        self.bg_height.setRange(100, 500)
        self.bg_height.setValue(180)
        self.bg_height.setSingleStep(10)
        self.bg_height.setToolTip("背景高度（像素）")
        
        bg_layout.addWidget(QLabel("背景宽度 (像素):"), 0, 0)
        bg_layout.addWidget(self.bg_width, 0, 1)
        bg_layout.addWidget(QLabel("背景高度 (像素):"), 1, 0)
        bg_layout.addWidget(self.bg_height, 1, 1)
        
        bg_group.setLayout(bg_layout)
        
        # 添加组件到右侧布局
        right_layout.addWidget(style_group)
        right_layout.addWidget(img_group)
        right_layout.addWidget(subtitle_pos_group)
        right_layout.addWidget(bg_group)
        right_layout.addStretch()
        
        # 将左右两侧添加到分栏器
        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        
        # 设置分栏器初始大小
        splitter.setSizes([400, 500])
        
        # 添加分栏器到主布局
        main_layout.addWidget(splitter)
        
        # 操作按钮
        process_btn = QPushButton("处理选中视频")
        process_btn.setMinimumHeight(40)
        process_btn.clicked.connect(self.process_videos)
        
        main_layout.addWidget(process_btn)
    
    def init_settings_tab(self):
        """初始化设置标签页"""
        layout = QVBoxLayout(self.settings_tab)
        
        # 字体设置组
        font_group = QGroupBox("字体设置")
        font_layout = QGridLayout()
        
        self.font_path_label = QLabel("字体目录: " + str(get_data_path("fonts")))
        font_open_btn = QPushButton("打开字体目录")
        font_open_btn.clicked.connect(self.open_font_dir)
        
        font_layout.addWidget(self.font_path_label, 0, 0, 1, 2)
        font_layout.addWidget(font_open_btn, 1, 0)
        
        font_group.setLayout(font_layout)
        
        # 样式设置组
        style_config_group = QGroupBox("样式配置")
        style_config_layout = QGridLayout()
        
        self.style_path_label = QLabel("样式配置文件: " + str(get_data_path("config") / "subtitle_styles.ini"))
        style_open_btn = QPushButton("打开样式配置")
        style_open_btn.clicked.connect(self.open_style_config)
        style_reload_btn = QPushButton("重新加载样式")
        style_reload_btn.clicked.connect(self.reload_styles)
        
        style_config_layout.addWidget(self.style_path_label, 0, 0, 1, 2)
        style_config_layout.addWidget(style_open_btn, 1, 0)
        style_config_layout.addWidget(style_reload_btn, 1, 1)
        
        style_config_group.setLayout(style_config_layout)
        
        # 默认设置组
        default_group = QGroupBox("默认设置")
        default_layout = QGridLayout()
        
        self.save_paths_check = QCheckBox("记住上一次的文件路径")
        self.save_paths_check.setChecked(True)
        
        self.default_qt_check = QCheckBox("默认使用QuickTime兼容模式")
        self.default_qt_check.setChecked(False)
        
        default_layout.addWidget(self.save_paths_check, 0, 0)
        default_layout.addWidget(self.default_qt_check, 1, 0)
        
        default_group.setLayout(default_layout)
        
        # 保存按钮
        save_btn = QPushButton("保存设置")
        save_btn.clicked.connect(self.save_settings)
        
        # 添加所有组件到布局
        layout.addWidget(font_group)
        layout.addWidget(style_config_group)
        layout.addWidget(default_group)
        layout.addWidget(save_btn)
        layout.addStretch()
    
    def populate_style_combo(self, combo_box):
        """填充样式下拉框"""
        combo_box.clear()
        combo_box.addItem("随机", "random")
        
        # 从样式配置中读取可用样式
        styles = []
        for section in self.style_config.sections():
            if section.startswith("styles."):
                style_name = section.replace("styles.", "")
                styles.append(style_name)
        
        # 添加样式到下拉框
        for style in sorted(styles):
            # 获取样式描述
            style_section = f"styles.{style}"
            description = ""
            
            # 尝试获取注释作为描述
            if self.style_config.has_option(style_section, "; 样式配置"):
                comment_text = self.style_config.get(style_section, "; 样式配置")
                for line in comment_text.split("\n"):
                    if line.strip() and not line.strip().startswith("["):
                        description = line.strip()
                        break
            
            # 如果没有注释，查看第一个非空行
            if not description:
                for option in self.style_config.options(style_section):
                    if option.startswith(";") and not option.startswith("; "):
                        description = option.lstrip(";").strip()
                        break
            
            # 如果仍然没有描述，使用样式名称
            if not description:
                description = style
            
            # 添加到下拉框
            combo_box.addItem(f"{style} - {description}", style)
    
    def add_video_files(self):
        """添加视频文件到列表"""
        initial_dir = self.settings.value("last_video_dir", "")
        file_paths, _ = QFileDialog.getOpenFileNames(
            self, "选择视频文件", 
            initial_dir,
            "视频文件 (*.mp4 *.mov *.avi *.wmv *.mkv);;所有文件 (*)"
        )
        
        if file_paths:
            # 保存最后访问的目录
            self.settings.setValue("last_video_dir", str(Path(file_paths[0]).parent))
            
            # 添加文件到列表
            for file_path in file_paths:
                if not self._is_file_in_list(file_path):
                    self.video_list.addItem(file_path)
            
            # 如果输出目录为空，默认设为第一个视频所在目录
            if not self.output_dir.text() and file_paths:
                self.output_dir.setText(str(Path(file_paths[0]).parent))
    
    def add_video_folder(self):
        """添加文件夹中的所有视频文件到列表"""
        initial_dir = self.settings.value("last_video_dir", "")
        folder_path = QFileDialog.getExistingDirectory(
            self, "选择包含视频文件的文件夹",
            initial_dir
        )
        
        if folder_path:
            self.settings.setValue("last_video_dir", folder_path)
            
            # 查找文件夹中的视频文件
            video_extensions = ['.mp4', '.mov', '.avi', '.wmv', '.mkv']
            video_files = []
            
            try:
                for file in os.listdir(folder_path):
                    file_path = os.path.join(folder_path, file)
                    if (os.path.isfile(file_path) and 
                        any(file.lower().endswith(ext) for ext in video_extensions)):
                        video_files.append(file_path)
                
                # 排序并添加到列表
                video_files.sort()
                for file_path in video_files:
                    if not self._is_file_in_list(file_path):
                        self.video_list.addItem(file_path)
                
                # 如果找到了视频并且输出目录为空，设置默认输出目录
                if video_files and not self.output_dir.text():
                    default_output = os.path.join(folder_path, "output")
                    self.output_dir.setText(default_output)
                    
                if not video_files:
                    QMessageBox.information(self, "提示", "所选文件夹中没有找到视频文件")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"读取文件夹失败: {str(e)}")
    
    def _is_file_in_list(self, file_path):
        """检查文件是否已经在列表中"""
        for i in range(self.video_list.count()):
            if self.video_list.item(i).text() == file_path:
                return True
        return False
    
    def clear_video_list(self):
        """清空视频列表"""
        self.video_list.clear()
    
    def browse_output_dir(self):
        """浏览选择输出目录"""
        initial_dir = self.output_dir.text() or self.settings.value("last_output_dir", "")
        if not initial_dir and self.video_list.count() > 0:
            # 如果输出目录为空，使用第一个视频的目录作为起始
            initial_dir = str(Path(self.video_list.item(0).text()).parent)
            
        dir_path = QFileDialog.getExistingDirectory(
            self, "选择输出目录",
            initial_dir
        )
        
        if dir_path:
            self.output_dir.setText(dir_path)
            self.settings.setValue("last_output_dir", dir_path)
    
    def process_videos(self):
        """处理选中的视频"""
        # 获取选中的视频文件
        selected_items = self.video_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "警告", "请选择要处理的视频文件")
            return
        
        video_paths = [item.text() for item in selected_items]
        
        output_dir = self.output_dir.text()
        if not output_dir:
            QMessageBox.warning(self, "警告", "请选择输出目录")
            return
        
        # 确保输出目录存在
        try:
            os.makedirs(output_dir, exist_ok=True)
        except Exception as e:
            QMessageBox.critical(self, "错误", f"无法创建输出目录: {str(e)}")
            return
        
        # 获取选择的样式和语言
        style_idx = self.style_combo.currentIndex()
        style = self.style_combo.itemData(style_idx)
        
        lang_idx = self.lang_combo.currentIndex()
        lang = self.lang_combo.itemData(lang_idx)
        
        # 获取所有设置参数
        quicktime_compatible = self.quicktime_check.isChecked()
        img_position_x = self.img_x.value()
        img_position_y = self.img_y.value()
        font_size = self.font_size.value()
        subtitle_x = self.subtitle_x.value()
        subtitle_y = self.subtitle_y.value()
        bg_width = self.bg_width.value()
        bg_height = self.bg_height.value()
        img_size = self.img_size.value()
        
        # 启动处理线程
        self.processing_thread = ProcessingThread(
            video_paths, output_dir, style, lang, 
            quicktime_compatible, img_position_x, img_position_y,
            font_size, subtitle_x, subtitle_y, bg_width, bg_height, img_size,
            self.subtitle_text_x.value(), self.subtitle_text_y.value()
        )
        
        self.processing_thread.progress_updated.connect(self.update_progress)
        self.processing_thread.processing_complete.connect(self.processing_finished)
        
        # 禁用界面
        self.disable_ui()
        
        # 开始处理
        self.processing_thread.start()
        
        # 保存设置
        self.save_current_settings()
    
    def update_progress(self, value, message):
        """更新进度条和状态栏"""
        self.progress_bar.setValue(value)
        self.status_bar.showMessage(message)
    
    def processing_finished(self, success, message):
        """处理完成后的操作"""
        # 恢复界面
        self.enable_ui()
        
        # 显示结果
        if success:
            QMessageBox.information(self, "处理完成", message)
        else:
            QMessageBox.warning(self, "处理失败", message)
            
        # 如果处理失败，打开输出目录以便检查
        if not success and hasattr(self, 'processing_thread'):
            output_dir = self.output_dir.text()
            if output_dir and os.path.exists(output_dir):
                try:
                    if sys.platform == "win32":
                        os.startfile(output_dir)
                    elif sys.platform == "darwin":  # macOS
                        subprocess.run(["open", output_dir])
                    else:  # Linux
                        subprocess.run(["xdg-open", output_dir])
                except Exception:
                    pass  # 忽略打开目录的错误
    
    def disable_ui(self):
        """禁用界面控件"""
        self.tabs.setEnabled(False)
        self.progress_bar.setValue(0)
    
    def enable_ui(self):
        """启用界面控件"""
        self.tabs.setEnabled(True)
    
    def open_font_dir(self):
        """打开字体目录"""
        font_dir = get_data_path("fonts")
        os.makedirs(font_dir, exist_ok=True)
        
        # 根据不同平台打开目录
        try:
            if sys.platform == "win32":
                os.startfile(font_dir)
            elif sys.platform == "darwin":  # macOS
                subprocess.run(["open", font_dir])
            else:  # Linux
                subprocess.run(["xdg-open", font_dir])
        except Exception as e:
            QMessageBox.warning(self, "警告", f"无法打开字体目录: {str(e)}")
    
    def open_style_config(self):
        """打开样式配置文件"""
        style_config_path = get_data_path("config") / "subtitle_styles.ini"
        os.makedirs(os.path.dirname(style_config_path), exist_ok=True)
        
        if not os.path.exists(style_config_path):
            QMessageBox.warning(self, "警告", "样式配置文件不存在")
            return
            
        # 根据不同平台打开文件
        try:
            if sys.platform == "win32":
                os.startfile(style_config_path)
            elif sys.platform == "darwin":  # macOS
                subprocess.run(["open", "-t", style_config_path])
            else:  # Linux
                subprocess.run(["xdg-open", style_config_path])
        except Exception as e:
            QMessageBox.warning(self, "警告", f"无法打开配置文件: {str(e)}")
    
    def reload_styles(self):
        """重新加载样式配置"""
        try:
            # 重新加载样式配置
            self.style_config = load_style_config()
            
            # 重新填充样式下拉框
            self.populate_style_combo(self.style_combo)
            
            # 显示成功消息
            QMessageBox.information(self, "成功", "样式配置已重新加载")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"重新加载样式配置失败: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def load_saved_settings(self):
        """加载保存的设置"""
        # 是否记住路径
        save_paths = self.settings.value("save_paths", True, type=bool)
        self.save_paths_check.setChecked(save_paths)
        
        # QuickTime兼容模式
        quicktime = self.settings.value("default_quicktime", False, type=bool)
        self.default_qt_check.setChecked(quicktime)
        self.quicktime_check.setChecked(quicktime)
        
        # 路径设置
        if save_paths:
            # 输出目录
            self.output_dir.setText(self.settings.value("output_dir", ""))
        
        # 样式和语言
        style_idx = self.settings.value("style_idx", 0, type=int)
        if 0 <= style_idx < self.style_combo.count():
            self.style_combo.setCurrentIndex(style_idx)
        
        lang_idx = self.settings.value("lang_idx", 0, type=int)
        if 0 <= lang_idx < self.lang_combo.count():
            self.lang_combo.setCurrentIndex(lang_idx)
                
        # 图片位置
        self.img_x.setValue(self.settings.value("img_x", 100, type=int))
        self.img_y.setValue(self.settings.value("img_y", 1280, type=int)) # 更新为1280
        
        # 字体大小
        self.font_size.setValue(self.settings.value("font_size", 70, type=int))
        
        # 字幕位置
        self.subtitle_x.setValue(self.settings.value("subtitle_x", -50, type=int))
        self.subtitle_y.setValue(self.settings.value("subtitle_y", 1100, type=int))
        self.subtitle_text_x.setValue(self.settings.value("subtitle_text_x", 0, type=int))
        self.subtitle_text_y.setValue(self.settings.value("subtitle_text_y", 1190, type=int))
        
        # 背景大小
        self.bg_width.setValue(self.settings.value("bg_width", 1000, type=int))
        self.bg_height.setValue(self.settings.value("bg_height", 180, type=int))
        
        # 图片大小
        self.img_size.setValue(self.settings.value("img_size", 420, type=int))
    
    def save_current_settings(self):
        """保存当前设置"""
        # 保存样式和语言选择
        self.settings.setValue("style_idx", self.style_combo.currentIndex())
        self.settings.setValue("lang_idx", self.lang_combo.currentIndex())
        
        # 保存QuickTime兼容模式
        self.settings.setValue("quicktime", self.quicktime_check.isChecked())
        
        # 保存图片位置
        self.settings.setValue("img_x", self.img_x.value())
        self.settings.setValue("img_y", self.img_y.value())
        
        # 保存字体大小
        self.settings.setValue("font_size", self.font_size.value())
        
        # 保存字幕位置
        self.settings.setValue("subtitle_x", self.subtitle_x.value())
        self.settings.setValue("subtitle_y", self.subtitle_y.value())
        self.settings.setValue("subtitle_text_x", self.subtitle_text_x.value())
        self.settings.setValue("subtitle_text_y", self.subtitle_text_y.value())
        
        # 保存背景大小
        self.settings.setValue("bg_width", self.bg_width.value())
        self.settings.setValue("bg_height", self.bg_height.value())
        
        # 保存图片大小
        self.settings.setValue("img_size", self.img_size.value())
        
        # 保存输出目录
        self.settings.setValue("output_dir", self.output_dir.text())
    
    def save_settings(self):
        """保存设置"""
        self.settings.setValue("save_paths", self.save_paths_check.isChecked())
        self.settings.setValue("default_quicktime", self.default_qt_check.isChecked())
        
        # 应用QuickTime兼容模式设置
        quicktime = self.default_qt_check.isChecked()
        self.quicktime_check.setChecked(quicktime)
        
        # 保存当前设置
        self.save_current_settings()
        
        QMessageBox.information(self, "设置已保存", "设置已成功保存")

    def closeEvent(self, event):
        """处理窗口关闭事件"""
        # 如果有正在运行的线程，提示用户确认
        if hasattr(self, 'processing_thread') and self.processing_thread and self.processing_thread.isRunning():
            reply = QMessageBox.question(
                self, '确认退出', 
                '有正在进行的处理任务，确定要退出吗？',
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                # 尝试结束线程
                if self.processing_thread.isRunning():
                    self.processing_thread.terminate()
                    self.processing_thread.wait(3000)  # 等待最多3秒
                    
                # 保存设置
                self.save_current_settings()
                event.accept()
            else:
                event.ignore()
        else:
            # 保存设置
            self.save_current_settings()
            event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = VideoProcessorApp()
    window.show()
    sys.exit(app.exec_()) 