#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频核心处理模块
负责视频处理的主要逻辑，包括视频长度判断、放大裁剪、添加字幕等功能
"""

import os
import subprocess
import sys
import shutil
from pathlib import Path
import tempfile
import random
import pandas as pd
from PIL import Image, ImageDraw, ImageOps, ImageFont
import time

# 导入工具函数
from utils import get_video_info, run_ffmpeg_command, get_data_path, find_matching_file, ensure_dir, create_subtitle_image, load_subtitle_config, load_style_config, find_font_file


def create_rounded_rect_background(width, height, radius, output_path, bg_color=(0, 0, 0, 128), sample_frame=None):
    """
    创建圆角矩形透明背景
    
    参数:
        width: 背景宽度
        height: 背景高度
        radius: 圆角半径
        output_path: 输出路径
        bg_color: 背景颜色和透明度，默认为半透明黑色
        sample_frame: 视频帧样本，用于取色
        
    返回:
        背景图片路径
    """
    try:
        # 如果提供了视频帧，从中取色
        if sample_frame is not None:
            try:
                # 从视频中间位置取色
                frame_width, frame_height = sample_frame.size
                # 取视频中心点的颜色
                sample_color = sample_frame.getpixel((frame_width // 2, frame_height // 2))
                
                # 如果是RGB图像，添加透明度
                if len(sample_color) == 3:
                    bg_color = (sample_color[0], sample_color[1], sample_color[2], 128)  # 半透明
                else:
                    # 已经是RGBA，只修改透明度
                    bg_color = (sample_color[0], sample_color[1], sample_color[2], 128)
                    
                print(f"从视频中取色: {bg_color}")
            except Exception as e:
                print(f"从视频取色失败，使用默认颜色: {e}")
                
        # 创建透明背景
        image = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        
        # 绘制圆角矩形
        draw.rounded_rectangle([(0, 0), (width-1, height-1)], radius=radius, fill=bg_color)
        
        # 保存图片
        image.save(output_path)
        print(f"圆角矩形背景已保存: {output_path}")
        return output_path
    except Exception as e:
        print(f"创建圆角矩形背景失败: {e}")
        return None


def process_video(video_path, output_path=None, style=None, subtitle_lang=None, 
                 quicktime_compatible=False, img_position_x=100, img_position_y=0,
                 font_size=70, subtitle_x=-50, subtitle_y=1100, bg_width=1000, bg_height=180, img_size=420,
                 subtitle_text_x=0, subtitle_text_y=1190):
    """
    处理视频的主函数
    
    参数:
        video_path: 视频文件路径
        output_path: 输出文件路径，默认为None（自动生成）
        style: 字幕样式，如果为None则随机选择
        subtitle_lang: 字幕语言，如果为None则随机选择
        quicktime_compatible: 是否生成QuickTime兼容的视频
        img_position_x: 图片水平位置系数（视频宽度的百分比，默认0.15，即15%）
        img_position_y: 图片垂直位置偏移（相对于背景位置，默认120像素向下偏移）
        font_size: 字体大小（像素，默认70）
        subtitle_x: 字幕X轴位置（像素，默认43）
        subtitle_y: 字幕Y轴位置（像素，默认1248）
        bg_width: 背景宽度（像素，默认1000）
        bg_height: 背景高度（像素，默认180）
        img_size: 图片大小（像素，默认420）
        
    返回:
        处理后的视频路径，失败返回None
    """
    print(f"开始处理视频: {video_path}")
    print(f"图片位置设置: 水平={img_position_x}（宽度比例）, 垂直={img_position_y}（像素偏移）")
    
    # 如果未指定输出路径，则生成一个
    if not output_path:
        video_name = Path(video_path).stem
        # 修改为指定的输出目录
        output_dir = Path("/Users/jerry/Documents/VS code file/video+number_backup_20250704_163846-带价格/VideoApp/output")
        # 确保输出目录存在
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / f"{video_name}_processed.mp4"
    
    # 创建临时目录
    temp_dir = Path(tempfile.mkdtemp())
    print(f"使用临时目录: {temp_dir}")
    
    try:
        # 1. 获取视频信息
        video_info = get_video_info(video_path)
        if not video_info:
            print("无法获取视频信息，处理失败")
            return None
            
        width, height, duration = video_info
        print(f"视频信息: {width}x{height}, {duration}秒")
        
        # 2. 根据视频长度决定处理方式
        if duration < 9.0:
            print(f"短视频 ({duration}秒): 将进行正放+倒放处理")
            processed_path = process_short_video(video_path, temp_dir)
        else:
            print(f"长视频 ({duration}秒): 将直接进行处理")
            processed_path = process_normal_video(video_path, temp_dir)
            
        if not processed_path:
            print("视频预处理失败")
            return None
            
        # 3. 添加字幕和其他效果，传递所有参数
        final_path = add_subtitle_to_video(
            processed_path, 
            output_path, 
            style, 
            subtitle_lang, 
            video_path, 
            quicktime_compatible=quicktime_compatible,
            img_position_x=img_position_x,
            img_position_y=img_position_y,
            font_size=font_size,
            subtitle_x=subtitle_x,
            subtitle_y=subtitle_y,
            bg_width=bg_width,
            bg_height=bg_height,
            img_size=img_size,
            subtitle_text_x=subtitle_text_x,
            subtitle_text_y=subtitle_text_y
        )
        
        if not final_path:
            print("添加字幕失败")
            return None
            
        print(f"视频处理完成: {final_path}")
        return final_path
        
    except Exception as e:
        print(f"处理视频时出错: {e}")
        import traceback
        traceback.print_exc()
        return None
    finally:
        # 清理临时文件
        try:
            import shutil
            shutil.rmtree(temp_dir)
        except:
            pass


def process_short_video(video_path, temp_dir):
    """
    处理短视频（5秒以下），进行正放+倒放拼接
    
    参数:
        video_path: 输入视频路径
        temp_dir: 临时目录
        
    返回:
        处理后的视频路径
    """
    output_path = temp_dir / "forward_reverse.mp4"
    
    # 使用一条命令完成正放+倒放+拼接
    cmd = [
        'ffmpeg', '-y', '-i', str(video_path),
        '-filter_complex',
        f'[0:v]trim=duration=5,setpts=PTS-STARTPTS[forward];'
        f'[0:v]trim=duration=5,setpts=PTS-STARTPTS,reverse[reversed];'
        f'[forward][reversed]concat=n=2:v=1:a=0[v]',
        '-map', '[v]',
        '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
        '-profile:v', 'main', '-level', '3.1',
        '-preset', 'ultrafast',
        '-crf', "23",  
        '-b:v', "4M",       
        '-movflags', '+faststart',
        '-brand', 'mp42',  # 设置兼容的品牌标记
        '-tag:v', 'avc1',  # 使用标准AVC标记
        '-an',  # 不要音频
        str(output_path)
    ]
    
    if run_ffmpeg_command(cmd):
        return output_path
    
    # 如果上面的命令失败，尝试传统方法
    print("使用备用方法处理短视频")
    
    # 1. 提取前5秒
    forward_path = temp_dir / "forward.mp4"
    cmd_forward = [
        'ffmpeg', '-y', '-i', str(video_path),
        '-t', '5',  # 截取前5秒
        '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
        '-profile:v', 'main', '-level', '3.1',
        '-preset', 'ultrafast', 
        '-brand', 'mp42',  # 设置兼容的品牌标记
        '-tag:v', 'avc1',  # 使用标准AVC标记
        '-an',  # 不要音频
        str(forward_path)
    ]
    if not run_ffmpeg_command(cmd_forward):
        return None
        
    # 2. 创建倒放视频
    reverse_path = temp_dir / "reverse.mp4"
    cmd_reverse = [
        'ffmpeg', '-y', '-i', str(forward_path),
        '-vf', 'reverse',  # 倒放滤镜
        '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
        '-profile:v', 'main', '-level', '3.1',
        '-preset', 'ultrafast',
        '-brand', 'mp42',  # 设置兼容的品牌标记
        '-tag:v', 'avc1',  # 使用标准AVC标记
        '-an',  # 不要音频
        str(reverse_path)
    ]
    if not run_ffmpeg_command(cmd_reverse):
        return None
        
    # 3. 拼接视频
    concat_file = temp_dir / "concat.txt"
    with open(concat_file, 'w') as f:
        f.write(f"file '{forward_path}'\n")
        f.write(f"file '{reverse_path}'\n")
    
    cmd_concat = [
        'ffmpeg', '-y', 
        '-f', 'concat', '-safe', '0',
        '-i', str(concat_file),
        '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
        '-profile:v', 'main', '-level', '3.1',
        '-preset', 'ultrafast',
        '-brand', 'mp42',  # 设置兼容的品牌标记
        '-tag:v', 'avc1',  # 使用标准AVC标记
        '-an',  # 不要音频
        str(output_path)
    ]
    
    if run_ffmpeg_command(cmd_concat):
        return output_path
    
    return None


def process_normal_video(video_path, temp_dir):
    """
    处理普通长度视频（无需正倒放）
    
    参数:
        video_path: 输入视频路径
        temp_dir: 临时目录
        
    返回:
        处理后的视频路径
    """
    output_path = temp_dir / "processed.mp4"
    
    # 获取视频信息
    video_info = get_video_info(video_path)
    if not video_info:
        return None
        
    width, height, duration = video_info
    
    # 1. 进行放大和裁剪以去除水印
    scale = 1.12  # 放大比例
    target_width = 1080
    target_height = 1920
    crop_y_offset = -220  # 向上偏移以去除底部水印
    
    # 确保宽高为偶数
    target_width = target_width - (target_width % 2)
    target_height = target_height - (target_height % 2)
    
    # 计算缩放后的尺寸
    scaled_w = int(width * scale)
    scaled_h = int(height * scale)
    
    # 调整为偶数
    scaled_w = scaled_w - (scaled_w % 2)
    scaled_h = scaled_h - (scaled_h % 2)
    
    # 向左偏移以彻底去除左上角水印框
    # 计算向左偏移的像素值（向右对齐）
    left_offset = 150  # 向左移动150像素
    
    # 计算裁剪区域，向左偏移以去除左上角水印
    crop_x = max(0, (scaled_w - target_width) // 2 + left_offset)  # 从右侧裁剪，向左偏移
    crop_y = max(0, (scaled_h - target_height) // 2 + crop_y_offset)  # 考虑Y轴偏移
    
    # 确保裁剪区域在有效范围内
    crop_x = min(crop_x, scaled_w - target_width)
    crop_y = min(crop_y, scaled_h - target_height)
    crop_y = max(0, crop_y)  # 确保不会小于0
    
    print(f"裁剪区域: X={crop_x}, Y={crop_y}, 宽={target_width}, 高={target_height}")
    
    # 使用ffmpeg进行放大和裁剪
    cmd = [
        'ffmpeg', '-y', '-i', str(video_path),
        '-vf', f'scale={scaled_w}:{scaled_h},crop={target_width}:{target_height}:{crop_x}:{crop_y}',
        '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
        '-profile:v', 'main', '-level', '3.1',
        '-preset', 'ultrafast',
        '-brand', 'mp42',  # 设置兼容的品牌标记
        '-tag:v', 'avc1',  # 使用标准AVC标记
        '-an',  # 不要音频
        str(output_path)
    ]
    
    if run_ffmpeg_command(cmd):
        return output_path
        
    return None


def add_subtitle_to_video(video_path, output_path, style=None, subtitle_lang=None, 
                        original_video_path=None, quicktime_compatible=False, 
                        img_position_x=100, img_position_y=0, font_size=70, 
                        subtitle_x=-50, subtitle_y=1100, bg_width=1000, bg_height=180, img_size=420,
                        subtitle_text_x=0, subtitle_text_y=1190):
    """
    添加字幕到视频
    
    参数:
        video_path: 输入视频路径
        output_path: 输出视频路径
        style: 字幕样式，如果为None则随机选择
        subtitle_lang: 字幕语言，如果为None则随机选择
        original_video_path: 原始视频路径（用于查找匹配的图片）
        quicktime_compatible: 是否生成QuickTime兼容的视频
        img_position_x: 图片水平位置系数（视频宽度的百分比，默认0.15，即15%）
        img_position_y: 图片垂直位置偏移（相对于背景位置，默认120像素向下偏移）
        font_size: 字体大小（像素，默认70）
        subtitle_x: 字幕X轴位置（像素，默认43）
        subtitle_y: 字幕Y轴位置（像素，默认1248）
        bg_width: 背景宽度（像素，默认1000）
        bg_height: 背景高度（像素，默认180）
        img_size: 图片大小（像素，默认420）
        
    返回:
        处理后的视频路径
    """
    # 创建临时目录
    temp_dir = Path(tempfile.mkdtemp())
    print(f"使用临时目录: {temp_dir}")
    
    try:
        # 1. 获取视频信息
        video_info = get_video_info(video_path)
        if not video_info:
            print("无法获取视频信息")
            return None
            
        width, height, duration = video_info
        print(f"视频信息: {width}x{height}, {duration}秒")
        
        # 2. 加载字幕配置
        subtitle_config_path = get_data_path("config/subtitle.csv")
        if not os.path.exists(subtitle_config_path):
            print(f"字幕配置文件不存在: {subtitle_config_path}")
            return None
            
        try:
            subtitle_df = pd.read_csv(subtitle_config_path)
            print(f"已加载字幕配置: {len(subtitle_df)} 条记录")
        except Exception as e:
            print(f"加载字幕配置失败: {e}")
            return None
            
        # 3. 随机选择样式和语言（如果未指定或者是"random"）
        if style is None or style == "random":
            # 从配置文件中动态获取所有可用的样式
            style_config = load_style_config()
            available_styles = []
            for section in style_config.sections():
                if section.startswith("styles."):
                    style_name = section.replace("styles.", "")
                    available_styles.append(style_name)
            
            # 如果没有找到任何样式，使用默认样式列表
            if not available_styles:
                available_styles = ["style1", "style2", "style3", "style4", "style5", "style6", 
                                    "style7", "style8", "style9", "style10", "style11"]
            
            style = random.choice(available_styles)
            print(f"随机选择样式: {style} (从 {len(available_styles)} 种样式中选择)")
            
        if subtitle_lang is None:
            available_langs = ["malay", "thai"]
            subtitle_lang = random.choice(available_langs)
            print(f"随机选择语言: {subtitle_lang}")
        
        # 4. 查找匹配的图片
        has_image = False
        image_path = None
        
        # 使用原始视频路径查找匹配图片（如果有）
        if original_video_path:
            original_video_name = Path(original_video_path).stem
            image_path = find_matching_image(original_video_name)
            
        # 如果没有找到，使用当前视频路径
        if not image_path:
            video_name = Path(video_path).stem
            image_path = find_matching_image(video_name)
            
        if image_path:
            print(f"找到匹配的图片: {image_path}")
            # 处理图片，使用自定义尺寸
            processed_img_path = temp_dir / "processed_image.png"
            if process_image_for_overlay(image_path, processed_img_path, size=(img_size, img_size)):
                has_image = True
                print(f"图片处理成功: {processed_img_path}")
            else:
                print("图片处理失败")
        else:
            print("没有找到匹配的图片")
            
        # 5. 随机选择字幕
        subtitle_text = None
        
        # 根据语言随机选择一条字幕
        if subtitle_lang == "malay":
            # 马来西亚语言：只从title列中选择字幕
            available_subtitles = subtitle_df[subtitle_df['title'].notna() & (subtitle_df['title'] != "")]['title'].tolist()
            if available_subtitles:
                subtitle_text = str(random.choice(available_subtitles))
            else:
                # 如果没有可用字幕，使用默认字幕
                subtitle_text = "Grab cepat\nStok laris seperti roti canai"
            print(f"随机选择的马来西亚字幕: {subtitle_text}")
        else:  # thai
            # 泰国语言：只从title_thai列中选择字幕
            available_subtitles = subtitle_df[subtitle_df['title_thai'].notna() & (subtitle_df['title_thai'] != "")]['title_thai'].tolist()
            if available_subtitles:
                subtitle_text = str(random.choice(available_subtitles))
                # 替换下划线为空格（如果泰文使用下划线占位）
                if "_" in subtitle_text:
                    subtitle_text = subtitle_text.replace("_", " ")
            else:
                # 如果没有可用字幕，使用默认字幕
                subtitle_text = "ราคาพิเศษ\nซื้อเลยอย่ารอช้า"  # 泰文示例
            print(f"随机选择的泰国字幕: {subtitle_text}")
        
        # 6. 创建字幕图片
        subtitle_height = 500  # 字幕高度
        subtitle_img_path = temp_dir / "subtitle.png"
        
        # 调试信息：打印字体大小
        print(f"传递给create_subtitle_image的字体大小: {font_size}")
        
        # 使用传入的字体大小参数，而不是硬编码
        subtitle_img = create_subtitle_image(
            text=subtitle_text,
            style=style,
            width=width + 200,  # 增加字幕宽度，防止文字被截断
            height=subtitle_height,
            font_size=font_size,
            output_path=str(subtitle_img_path)
        )
        
        # 检查字幕生成结果
        if subtitle_img:
            print(f"字幕图片生成成功，路径: {subtitle_img}")
        else:
            print("警告：字幕图片生成失败")
        
        if not subtitle_img:
            print("创建字幕图片失败")
            return None
        
        # 7. 提取视频帧用于取色
        sample_frame_path = temp_dir / "sample_frame.jpg"
        sample_frame_cmd = [
            'ffmpeg', '-y',
            '-i', str(video_path),
            '-ss', '00:00:05',  # 从第5秒提取帧
            '-vframes', '1',
            '-q:v', '1',
            str(sample_frame_path)
        ]
        
        sample_frame = None
        try:
            subprocess.run(sample_frame_cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            sample_frame = Image.open(str(sample_frame_path))
            print(f"成功提取视频帧用于取色: {sample_frame_path}")
        except Exception as e:
            print(f"提取视频帧失败: {e}")
        
        # 8. 创建圆角矩形透明背景，使用自定义尺寸
        bg_img_path = temp_dir / "background.png"
        bg_radius = 20   # 圆角半径
        
        # 使用固定的半透明黑色背景，不从视频中取色
        bg_img = create_rounded_rect_background(
            width=bg_width,
            height=bg_height,
            radius=bg_radius,
            output_path=str(bg_img_path),
            bg_color=(0, 0, 0, 160)  # 使用固定的半透明黑色背景
        )
        
        if not bg_img:
            print("创建圆角矩形背景失败")
            return None
        
        # 9. 添加字幕和背景到视频（带动画效果）
        
        # 动画参数设置
        entrance_duration = 3.0  # 入场动画持续3秒
        fps = 30  # 帧率
        
        # 字幕X坐标 - 直接使用传入的绝对坐标
        x_position = int(subtitle_text_x)  # 字幕X轴绝对坐标
        
        # 首先确定背景位置 - 这是基础位置，其他元素都以此为基准
        bg_y_position = int(subtitle_y)  # 背景垂直位置直接使用传入的subtitle_y参数
        
        # 背景动画 - 水平方向
        bg_start_x = -bg_width
        bg_final_x = int(subtitle_x)  # 背景水平位置使用传入的subtitle_x参数
        
        # 字幕垂直位置 - 直接使用传入的绝对坐标
        # 字幕位置由subtitle_text_y参数直接指定
        final_y_position = int(subtitle_text_y)  # 字幕Y轴绝对坐标
        
        # 文字入场动画起始位置
        start_y_position = height + 50  # 动画起始位置（屏幕下方）
        
        # 图片水平位置参数
        img_x_position = int(img_position_x)  # 图片X轴绝对坐标
        
        # 图片垂直位置 - 直接使用传入的绝对坐标
        # 图片位置由img_position_y参数直接指定
        img_final_position = int(img_position_y)  # 图片Y轴绝对坐标
        
        img_start_x = -img_size  # 图片动画起始位置
        
        # 字幕X坐标 - 直接使用传入的绝对坐标
        subtitle_absolute_x = int(x_position)
        
        print(f"背景位置: x={bg_final_x}, y={bg_y_position}, 宽={bg_width}, 高={bg_height}")
        print(f"字幕动画参数: 入场时间={entrance_duration}秒, 起始位置=({subtitle_absolute_x}, {start_y_position}), 最终位置=({subtitle_absolute_x}, {final_y_position})")
        print(f"背景动画参数: 入场时间={entrance_duration}秒, 起始位置=({bg_start_x}, {bg_y_position}), 最终位置=({bg_final_x}, {bg_y_position})")
        print(f"图片动画参数: 入场时间={entrance_duration}秒, 起始位置=({img_start_x}, {img_final_position}), 最终位置=({img_x_position}, {img_final_position})")
        print(f"位置关系: 背景(x={bg_final_x}, y={bg_y_position}), 字幕(x={subtitle_absolute_x}, y={final_y_position}), 图片(x={img_x_position}, y={img_final_position})")
        
        # 构建FFmpeg命令来叠加字幕、背景和图片
        output_with_subtitle = temp_dir / "with_subtitle.mp4"
        
        # 添加QuickTime兼容性参数
        if quicktime_compatible:
            print("应用QuickTime兼容性参数")
        
        ffmpeg_command = [
            'ffmpeg', '-y',
            '-i', str(video_path),
            '-i', str(subtitle_img_path),
            '-i', str(bg_img_path)
        ]
        
        # 如果有图片，添加到命令中
        if has_image:
            ffmpeg_command.extend(['-i', str(processed_img_path)])
            
        # 添加复杂过滤器参数
        filter_complex = f"[0:v]trim=duration={duration}[v1];"
        
        # 格式化图层
        filter_complex += "[2:v]format=rgba[bg];"
        filter_complex += "[1:v]format=rgba[s1];"
        
        if has_image:
            filter_complex += "[3:v]format=rgba[img];"
            
        # 叠加背景，使用动画
        filter_complex += f"[v1][bg]overlay=x='if(lt(t,{entrance_duration}),{bg_start_x}+({bg_final_x}-({bg_start_x}))*t/{entrance_duration},{bg_final_x})':y={bg_y_position}:shortest=0:format=auto"
        
        # 如果有图片，叠加图片并添加动画
        if has_image:
            filter_complex += f"[v2];[v2][img]overlay=x='if(lt(t,{entrance_duration}),{img_start_x}+({img_x_position}-({img_start_x}))*t/{entrance_duration},{img_x_position})':y={img_final_position}:shortest=0:format=auto"
            next_output = "v3"
        else:
            next_output = "v2"
            
        # 叠加文字并添加动画 - 使用字幕绝对坐标
        filter_complex += f"[{next_output}];[{next_output}][s1]overlay=x={subtitle_absolute_x}:y='if(lt(t,{entrance_duration}),{start_y_position}-({start_y_position}-{final_y_position})*t/{entrance_duration},{final_y_position})':shortest=0:format=auto"
        
        # 完成命令构建
        ffmpeg_command.extend([
            '-filter_complex', filter_complex,
            '-c:v', 'libx264',
            '-pix_fmt', 'yuv420p',
            '-profile:v', 'main',
            '-level', '3.1',
            '-preset', 'ultrafast',
            '-movflags', '+faststart',
            '-brand', 'mp42',  # 设置兼容的品牌标记
            '-tag:v', 'avc1',  # 使用标准AVC标记
            '-an',  # 不要音频
            str(output_with_subtitle)
        ])
        
        # 执行命令
        print(f"执行命令: {' '.join(ffmpeg_command)}")
        result = run_ffmpeg_command(ffmpeg_command)
        
        if not result:
            print("添加字幕失败，尝试使用备用方法")
            return fallback_static_subtitle(video_path, subtitle_img_path, output_path, temp_dir, quicktime_compatible)
        
        # 10. 添加QuickTime兼容性（如果需要）
        final_cmd = [
            'ffmpeg', '-y',
            '-i', str(output_with_subtitle),
            '-c', 'copy',
            '-movflags', '+faststart',
            str(output_path)
        ]
        
        print(f"执行命令: {' '.join(final_cmd)}")
        if run_ffmpeg_command(final_cmd):
            print(f"成功添加字幕动画，输出到: {output_path}")
            return output_path
        else:
            print("最终转换失败")
            return None
            
    except Exception as e:
        print(f"添加字幕时出错: {e}")
        import traceback
        traceback.print_exc()
        return None
    finally:
        # 清理临时文件
        try:
            import shutil
            shutil.rmtree(temp_dir)
        except:
            pass


def fallback_static_subtitle(video_path, subtitle_img_path, output_path, temp_dir, quicktime_compatible=False):
    """
    静态字幕备用方案
    当动画字幕失败时使用
    
    参数:
        video_path: 视频路径
        subtitle_img_path: 字幕图片路径
        output_path: 输出路径
        temp_dir: 临时目录
        quicktime_compatible: 是否生成QuickTime兼容的视频
    """
    print("使用静态字幕备用方案" + (", QuickTime兼容模式" if quicktime_compatible else ""))
    
    # 获取视频信息
    video_info = get_video_info(video_path)
    if not video_info:
        return None
        
    width, height, duration = video_info
    
    # 计算字幕位置
    x_position = int(width * 0.08)  # 水平位置为视频宽度的8%
    y_position = int(height * 0.65)  # 垂直位置为视频高度的65%
    
    # 使用静态字幕
    output_with_subtitle = temp_dir / "with_static_subtitle.mp4"
    
    # 构建滤镜表达式
    filter_complex = (
        f"[0:v]trim=duration={duration}[v1];"
        f"[1:v]format=rgba[s1];"
        f"[v1][s1]overlay=x={x_position}:y={y_position}:shortest=0:format=auto"
    )
    
    # 直接将字幕添加到视频上
    cmd = [
        'ffmpeg', '-y',
        '-i', str(video_path),
        '-i', str(subtitle_img_path),
        '-filter_complex', filter_complex,
        '-c:v', 'libx264',
        '-pix_fmt', 'yuv420p',  # 确保输出格式是yuv420p
        '-profile:v', 'main', '-level', '3.1',
        '-preset', 'ultrafast',
        '-movflags', '+faststart',
    ]
    
    # 添加QuickTime兼容性参数
    if quicktime_compatible:
        cmd.extend([
            '-brand', 'mp42',  # 设置兼容的品牌标记
            '-tag:v', 'avc1',  # 使用标准AVC标记
        ])
        print("应用静态字幕的QuickTime兼容性参数")
    
    # 不要音频
    cmd.extend(['-an', str(output_with_subtitle)])
    
    if not run_ffmpeg_command(cmd):
        print("静态字幕添加失败")
        return None
    
    # 复制到最终输出路径
    ensure_dir(os.path.dirname(output_path))
    
    # 使用ffmpeg复制整个视频，而不是简单的文件复制
    copy_cmd = [
        'ffmpeg', '-y',
        '-i', str(output_with_subtitle),
        '-c', 'copy',  # 使用复制模式，不重新编码
        '-movflags', '+faststart',
        str(output_path)
    ]
    
    if not run_ffmpeg_command(copy_cmd):
        print(f"复制最终视频失败，尝试直接复制文件")
        shutil.copy2(output_with_subtitle, output_path)
    
    print(f"成功添加静态字幕，输出到: {output_path}")
    return output_path


def batch_process_videos(style=None, subtitle_lang=None, quicktime_compatible=False, img_position_x=0.15, img_position_y=120):
    """
    批量处理视频
    
    参数:
        style: 字幕样式，如果为None则每个视频随机选择，如果为"random"则强制每个视频随机选择
        subtitle_lang: 字幕语言，如果为"malay"则所有视频使用马来西亚字幕，如果为"thai"则所有视频使用泰国字幕
        quicktime_compatible: 是否生成QuickTime兼容的视频
        img_position_x: 图片水平位置系数（视频宽度的百分比，默认0.15，即15%）
        img_position_y: 图片垂直位置偏移（相对于背景位置，默认120像素向下偏移）
        
    返回:
        处理成功的视频数量
    """
    # 确保字幕语言是有效的选择
    if subtitle_lang not in ["malay", "thai", None, "random"]:
        print(f"警告：无效的字幕语言 '{subtitle_lang}'，将使用默认值")
        subtitle_lang = None
    
    # 如果是random，随机选择一种语言并固定使用
    if subtitle_lang == "random":
        subtitle_lang = random.choice(["malay", "thai"])
        print(f"随机选择并固定使用语言: {subtitle_lang}")
    
    print(f"批量处理视频，样式: {'随机' if style is None or style == 'random' else style}, 语言: {subtitle_lang}, QuickTime兼容模式: {'启用' if quicktime_compatible else '禁用'}")
    print(f"图片位置设置: 水平={img_position_x}（宽度比例）, 垂直={img_position_y}（像素偏移）")
    
    # 获取视频目录
    videos_dir = get_data_path("input/videos")
    # 修改为指定的输出目录
    output_dir = Path("/Users/jerry/Documents/VS code file/video+number_backup_20250704_163846-带价格/VideoApp/output")
    
    # 确保目录存在
    if not os.path.exists(videos_dir):
        os.makedirs(videos_dir)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 获取所有视频文件
    video_extensions = ['.mp4', '.mov', '.avi', '.wmv', '.mkv']
    video_files = []
    
    for ext in video_extensions:
        video_files.extend(list(Path(videos_dir).glob(f"*{ext}")))
    
    if not video_files:
        print("没有找到视频文件")
        return 0
    
    print(f"找到 {len(video_files)} 个视频文件")
    
    # 处理每个视频
    success_count = 0
    last_style = None  # 记录上一个视频使用的样式
    
    # 预先创建所有可能的样式
    all_styles = ["style1", "style2", "style3", "style4", "style5", "style6", "style7", "style8", "style9", "style10", "style11"]
    
    for video_path in video_files:
        print(f"\n处理视频: {video_path.name}")
        output_path = output_dir / f"{video_path.stem}_processed.mp4"
        
        # 为每个视频独立随机选择样式
        current_style = None
        if style == "random" or style is None:
            # 当style为"random"或None时，确保不会连续使用相同的样式
            available_styles = [s for s in all_styles if s != last_style]
            
            # 如果所有样式都已使用过一次，重置可用样式列表
            if len(available_styles) == 0:
                available_styles = all_styles.copy()
                if last_style in available_styles:
                    available_styles.remove(last_style)
            
            current_style = random.choice(available_styles)
            last_style = current_style
            
            print(f"随机选择样式（避免重复）: {current_style}")
        else:
            # 使用指定的样式
            current_style = style
            print(f"使用指定样式: {current_style}")
        
        try:
            if process_video(
                video_path, 
                output_path, 
                current_style, 
                subtitle_lang,  # 使用固定的语言选择
                quicktime_compatible=quicktime_compatible,
                img_position_x=img_position_x,
                img_position_y=img_position_y
            ):
                success_count += 1
                print(f"✅ 视频处理成功: {video_path.name}")
            else:
                print(f"❌ 视频处理失败: {video_path.name}")
        except Exception as e:
            print(f"❌ 处理视频时出错: {e}")
    
    print(f"\n批量处理完成: {success_count}/{len(video_files)} 个视频成功")
    return success_count


def find_matching_image(video_name, image_dir="input/images"):
    """
    查找与视频文件名匹配的图片
    
    参数:
        video_name: 视频文件名（不含扩展名）
        image_dir: 图片目录
        
    返回:
        匹配的图片路径，如果没有找到则返回None
    """
    try:
        print(f"查找匹配图片，视频名称: {video_name}")
        
        # 获取完整的图片目录路径
        # 1. 优先检查VideoApp/input/images目录
        videoapp_dir_path = os.path.join(os.getcwd(), "VideoApp/input/images")
        # 2. 然后检查当前目录下的input/images
        current_dir_path = os.path.join(os.getcwd(), "input/images")
        
        if os.path.exists(videoapp_dir_path):
            full_image_dir = videoapp_dir_path
            print(f"使用VideoApp下的图片目录: {full_image_dir}")
        elif os.path.exists(current_dir_path):
            full_image_dir = current_dir_path
            print(f"使用当前工作目录下的图片目录: {full_image_dir}")
        elif image_dir.startswith("../"):
            # 如果是相对路径，直接使用
            full_image_dir = image_dir
            print(f"使用相对路径图片目录: {full_image_dir}")
        else:
            # 否则使用get_data_path函数
            full_image_dir = get_data_path(image_dir)
            print(f"使用get_data_path获取图片目录: {full_image_dir}")
        
        print(f"最终图片目录路径: {full_image_dir}")
            
        if not os.path.exists(full_image_dir):
            print(f"图片目录不存在: {full_image_dir}")
            # 尝试创建目录
            try:
                os.makedirs(full_image_dir, exist_ok=True)
                print(f"已创建图片目录: {full_image_dir}")
            except Exception as e:
                print(f"创建图片目录失败: {e}")
            return None
        
        # 列出目录中所有文件
        all_files = os.listdir(full_image_dir)
        print(f"目录中的文件数量: {len(all_files)}")
        print(f"目录中的所有文件: {all_files}")
            
        # 支持的图片扩展名
        image_extensions = ['.jpg', '.jpeg', '.png', '.webp']
        
        # 查找完全匹配的图片
        for ext in image_extensions:
            image_path = os.path.join(full_image_dir, f"{video_name}{ext}")
            if os.path.exists(image_path):
                print(f"找到完全匹配的图片: {image_path}")
                return image_path
        
        # 如果没有完全匹配，查找包含视频名称的图片
        matched_images = []
        for file in all_files:
            file_path = os.path.join(full_image_dir, file)
            if os.path.isfile(file_path) and any(file.lower().endswith(ext.lower()) for ext in image_extensions):
                print(f"检查文件: {file}")
                # 提取视频名称的关键部分（例如M2-romer_003）
                video_key = video_name.split('_')[0] if '_' in video_name else video_name
                if video_key.lower() in file.lower():
                    print(f"  - 匹配成功: {file} (关键词: {video_key})")
                    matched_images.append((file_path, len(file)))
                else:
                    print(f"  - 不匹配: {file}")
        
        # 按文件名长度排序，选择最短的（通常是最接近的匹配）
        if matched_images:
            matched_images.sort(key=lambda x: x[1])
            best_match = matched_images[0][0]
            print(f"找到最佳匹配的图片: {best_match}")
            return best_match
        
        # 如果没有匹配，返回目录中的第一张图片（如果有）
        for file in all_files:
            file_path = os.path.join(full_image_dir, file)
            if os.path.isfile(file_path) and any(file.lower().endswith(ext.lower()) for ext in image_extensions):
                print(f"没有匹配，使用目录中的第一张图片: {file_path}")
                return file_path
                    
        print(f"未找到与 {video_name} 匹配的图片，也没有找到任何可用图片")
        return None
    except Exception as e:
        print(f"查找匹配图片时出错: {e}")
        import traceback
        traceback.print_exc()
        return None


def process_image_for_overlay(image_path, output_path, size=(420, 420)):
    """
    处理图片以准备叠加到视频上
    
    参数:
        image_path: 输入图片路径
        output_path: 输出图片路径
        size: 输出图片大小，默认420x420像素
        
    返回:
        处理后的图片路径，失败返回None
    """
    try:
        print(f"处理图片: {image_path}")
        print(f"目标大小: {size}")
        
        # 打开图片
        img = Image.open(image_path)
        
        original_size = img.size
        print(f"原始图片大小: {original_size}")
            
        # 保持宽高比缩放
        width, height = img.size
        if width > height:
            new_width = size[0]
            new_height = int(height * (new_width / width))
        else:
            new_height = size[1]
            new_width = int(width * (new_height / height))
        
        # 缩放图片
        img = img.resize((new_width, new_height), Image.LANCZOS)
        print(f"缩放后图片大小: {img.size}")
        
        # 创建一个全透明的新图片作为背景
        new_img = Image.new('RGBA', size, (0, 0, 0, 0))
        
        # 计算粘贴位置（居中）
        paste_x = (size[0] - new_width) // 2
        paste_y = (size[1] - new_height) // 2
        
        # 粘贴缩放后的图片到中心
        new_img.paste(img, (paste_x, paste_y), img)
        
        # 保存处理后的图片
        new_img.save(output_path)
        print(f"图片处理完成，保存到: {output_path}")
        
        # 验证处理后的图片
        processed_img = Image.open(output_path)
        print(f"验证处理后图片大小: {processed_img.size}")
        
        return output_path
    except Exception as e:
        print(f"处理图片时出错: {e}")
        import traceback
        traceback.print_exc()
        return None


def create_subtitle_image(text, style="style1", width=1080, height=300, font_size=70, output_path=None):
    """
    创建字幕图片
    
    参数:
        text: 字幕文本
        style: 样式名称
        width: 图片宽度
        height: 图片高度
        font_size: 字体大小
        output_path: 输出路径
        
    返回:
        字幕图片路径
    """
    try:
        print(f"创建字幕图片: 宽={width}, 高={height}, 字体大小={font_size}, 样式={style}")
        print(f"字幕内容: {text}")
        
        # 检查是否包含泰文
        def contains_thai(s):
            # 泰文Unicode范围: 0E00-0E7F
            for char in s:
                if '\u0E00' <= char <= '\u0E7F':
                    return True
            return False
            
        is_thai_text = contains_thai(text)
        print(f"是否包含泰文: {is_thai_text}")
        
        # 如果没有指定输出路径，生成一个临时文件
        if not output_path:
            import tempfile
            output_path = os.path.join(tempfile.gettempdir(), f"subtitle_{int(time.time())}.png")
            
        # 创建透明背景的图片
        image = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        
        # 如果是"random"样式，先随机选择一个实际样式
        if style == "random":
            # 从配置文件中动态获取所有可用的样式
            style_config_parser = load_style_config()
            available_styles = []
            for section in style_config_parser.sections():
                if section.startswith("styles."):
                    style_name = section.replace("styles.", "")
                    available_styles.append(style_name)
            
            # 如果没有找到任何样式，使用默认样式列表
            if not available_styles:
                available_styles = ["style1", "style2", "style3", "style4", "style5", "style6", 
                                    "style7", "style8", "style9", "style10", "style11"]
            
            style = random.choice(available_styles)
            print(f"在create_subtitle_image中随机选择样式: {style} (从 {len(available_styles)} 种样式中选择)")
        
        # 加载样式配置
        style_config = load_style_config(style)
        if style_config:
            print(f"成功加载样式配置: {style_config}")
            
            # 获取字体路径
            font_path = style_config.get('font_path', 'data/fonts/BebasNeue-Regular.ttf')
            print(f"使用自定义字体路径: {font_path}")
            
            # 获取字体大小，始终使用传入的字体大小
            custom_font_size = font_size
            print(f"使用传入的字体大小: {custom_font_size}")
            
            # 获取文本颜色
            text_color = style_config.get('text_color', [255, 255, 255, 255])
            if isinstance(text_color, list):
                text_color = tuple(text_color)  # 转换列表为元组
            print(f"使用自定义文本颜色: {text_color}")
            
            # 获取描边颜色
            stroke_color = style_config.get('stroke_color', [0, 0, 0, 255])
            if isinstance(stroke_color, list):
                stroke_color = tuple(stroke_color)  # 转换列表为元组
            print(f"使用自定义描边颜色: {stroke_color}")
            
            # 获取描边宽度
            stroke_width = style_config.get('stroke_width', 2)
            print(f"使用自定义描边宽度: {stroke_width}")
            
            # 获取白色描边比例
            white_stroke_ratio = style_config.get('white_stroke_ratio', 1.2)
            print(f"使用自定义白色描边比例: {white_stroke_ratio}")
            
            # 获取阴影设置
            shadow = style_config.get('shadow', False)
            shadow_color = style_config.get('shadow_color', [0, 0, 0, 120])
            if isinstance(shadow_color, list):
                shadow_color = tuple(shadow_color)  # 转换列表为元组
            shadow_offset = style_config.get('shadow_offset', [4, 4])
            print(f"使用自定义阴影设置: {shadow}")
            print(f"使用自定义阴影颜色: {shadow_color}")
            print(f"使用自定义阴影偏移: {shadow_offset}")
        else:
            # 默认样式
            font_path = 'data/fonts/BebasNeue-Regular.ttf'
            custom_font_size = font_size
            text_color = (255, 255, 255, 255)
            stroke_color = (0, 0, 0, 255)
            stroke_width = 2
            white_stroke_ratio = 1.2
            shadow = False
            shadow_color = (0, 0, 0, 120)
            shadow_offset = (4, 4)
            
        # 查找字体文件
        font_file = find_font_file(font_path)
        if font_file:
            print(f"找到字体文件: {font_file}")
            try:
                # 加载字体
                font = ImageFont.truetype(font_file, custom_font_size)
                print(f"找到可用字体: {font_file}")
                print(f"成功加载字体 {font_file}，大小: {custom_font_size}")
            except Exception as e:
                print(f"加载字体失败: {e}")
                # 使用默认字体
                font = ImageFont.load_default()
                print("使用默认字体")
        else:
            # 使用默认字体
            font = ImageFont.load_default()
            print("找不到指定字体，使用默认字体")
            
        # 分割文本为多行
        lines = text.strip().split('\n')
        print(f"行数: {len(lines)}")
        
        # 计算行高和总高度
        line_height = int(custom_font_size * 1.3)  # 增加行高系数，从1.1倍改为1.3倍，解决小字体时行间距过小的问题
        total_height = line_height * len(lines)
        
        # 计算起始Y坐标，使文本垂直居中
        y_start = (height - total_height) // 2
        
        print(f"行高: {line_height}, 总高度: {total_height}, 起始Y: {y_start}")
        
        # 绘制每行文本
        for i, line in enumerate(lines):
            # 计算文本宽度以居中
            text_width = draw.textlength(line, font=font)
            x = (width - text_width) // 2
            y = y_start + i * line_height
            
            print(f"行 {i+1}: 宽度={text_width}, X={x}, Y={y}")
            
            # 绘制阴影（如果启用）
            if shadow:
                shadow_x = x + shadow_offset[0]
                shadow_y = y + shadow_offset[1]
                draw.text((shadow_x, shadow_y), line, font=font, fill=shadow_color)
            
            # 创建一个临时图像用于描边
            stroke_img = Image.new('RGBA', (width, height), (0, 0, 0, 0))
            stroke_draw = ImageDraw.Draw(stroke_img)
            
            # 使用描边绘制文本
            for dx in range(-stroke_width, stroke_width + 1):
                for dy in range(-stroke_width, stroke_width + 1):
                    if dx*dx + dy*dy <= stroke_width*stroke_width:
                        stroke_draw.text((x + dx, y + dy), line, font=font, fill=stroke_color)
            
            # 将描边图像合并到主图像
            image = Image.alpha_composite(image, stroke_img)
            draw = ImageDraw.Draw(image)
            
            # 绘制主文本
            draw.text((x, y), line, font=font, fill=text_color)
        
        # 保存图片
        image.save(output_path)
        print(f"字幕图片已保存: {output_path}")
        
        return output_path
    except Exception as e:
        print(f"创建字幕图片失败: {e}")
        import traceback
        traceback.print_exc()
        return None


# 主函数用于测试
if __name__ == "__main__":
    # 如果有命令行参数，处理指定视频
    if len(sys.argv) > 1:
        video_path = sys.argv[1]
        output_path = None
        if len(sys.argv) > 2:
            output_path = sys.argv[2]
            
        process_video(video_path, output_path)
    else:
        # 否则批量处理所有视频
        batch_process_videos()
