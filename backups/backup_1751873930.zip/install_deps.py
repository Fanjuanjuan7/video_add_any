#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
依赖安装脚本
帮助用户安装视频处理应用所需的依赖
"""

import os
import sys
import subprocess
import platform

def main():
    """主函数"""
    print("=== 视频处理应用依赖安装程序 ===")
    print(f"Python版本: {sys.version}")
    print(f"操作系统: {platform.system()} {platform.version()}\n")
    
    # 检查pip是否可用
    try:
        subprocess.run([sys.executable, "-m", "pip", "--version"], check=True, stdout=subprocess.PIPE)
        print("pip 已安装，将继续安装依赖\n")
    except Exception:
        print("错误: 找不到pip工具。请先安装pip后再运行此脚本。")
        sys.exit(1)
    
    # 要安装的依赖列表
    dependencies = [
        "PyQt5",       # GUI库
        "pillow",      # 图像处理
        "pandas",      # 数据处理
        "numpy",       # 数值计算
    ]
    
    # 询问用户是否继续
    print("将要安装以下依赖:")
    for dep in dependencies:
        print(f" - {dep}")
        
    choice = input("\n是否继续安装? [y/N]: ").strip().lower()
    if choice != 'y':
        print("安装已取消")
        return
    
    # 安装依赖
    print("\n开始安装依赖...\n")
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade"] + dependencies
    
    try:
        process = subprocess.run(cmd, check=True)
        
        if process.returncode == 0:
            print("\n✅ 依赖安装成功!")
            print("\n现在您可以运行应用程序:")
            print(f"  {sys.executable} video_app.py")
        else:
            print("\n❌ 依赖安装可能不完整，请查看上面的错误信息。")
    except Exception as e:
        print(f"\n❌ 安装失败: {e}")
        print("\n您可以尝试手动安装依赖:")
        print(f"pip install {' '.join(dependencies)}")

if __name__ == "__main__":
    main() 