#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频处理应用 GUI 界面
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import threading
import time
import subprocess

# 导入自定义模块
from utils import get_data_path, get_video_info
from video_core import process_video, batch_process_videos

class VideoProcessorApp:
    """视频处理应用类"""
    
    def __init__(self, root):
        """初始化应用"""
        self.root = root
        self.root.title("视频处理工具")
        self.root.geometry("800x600")
        self.root.minsize(800, 600)
        
        # 设置样式
        self.style = ttk.Style()
        self.style.configure("TButton", padding=6, relief="flat", background="#ccc")
        self.style.configure("TLabel", padding=6)
        self.style.configure("TFrame", background="#f0f0f0")
        
        # 创建主框架
        self.main_frame = ttk.Frame(self.root, padding="10")
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建标题
        title_label = ttk.Label(self.main_frame, text="视频处理工具", font=("Arial", 18, "bold"))
        title_label.pack(pady=10)
        
        # 创建选项卡
        self.tab_control = ttk.Notebook(self.main_frame)
        
        # 单个视频处理选项卡
        self.single_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.single_tab, text="单个视频处理")
        
        # 批量处理选项卡
        self.batch_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.batch_tab, text="批量处理")
        
        # 设置选项卡
        self.settings_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.settings_tab, text="设置")
        
        self.tab_control.pack(expand=1, fill="both")
        
        # 初始化各个选项卡的内容
        self.init_single_tab()
        self.init_batch_tab()
        self.init_settings_tab()
        
        # 状态栏
        self.status_frame = ttk.Frame(self.root, relief=tk.SUNKEN)
        self.status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.status_label = ttk.Label(self.status_frame, text="就绪")
        self.status_label.pack(side=tk.LEFT, padx=5)
        
        # 进度条
        self.progress = ttk.Progressbar(self.status_frame, orient=tk.HORIZONTAL, length=200, mode='determinate')
        self.progress.pack(side=tk.RIGHT, padx=5, pady=5)
        
        # 处理线程
        self.processing_thread = None
        self.stop_event = threading.Event()
        
        # 配置
        self.load_settings()
        
        # 初始化各目录
        self.videos_dir = get_data_path("input/videos")
        self.images_dir = get_data_path("input/images")
        self.output_dir = get_data_path("output")
        
    def init_single_tab(self):
        """初始化单个视频处理选项卡"""
        # 视频路径选择
        file_frame = ttk.Frame(self.single_tab)
        file_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(file_frame, text="视频文件:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.video_path_var = tk.StringVar()
        video_entry = ttk.Entry(file_frame, textvariable=self.video_path_var, width=50)
        video_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W+tk.E)
        
        browse_btn = ttk.Button(file_frame, text="浏览...", command=self.browse_video)
        browse_btn.grid(row=0, column=2, padx=5, pady=5)
        
        # 输出路径选择
        ttk.Label(file_frame, text="输出文件:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.output_path_var = tk.StringVar()
        output_entry = ttk.Entry(file_frame, textvariable=self.output_path_var, width=50)
        output_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W+tk.E)
        
        save_btn = ttk.Button(file_frame, text="浏览...", command=self.browse_output)
        save_btn.grid(row=1, column=2, padx=5, pady=5)
        
        # 选项框架
        options_frame = ttk.LabelFrame(self.single_tab, text="处理选项")
        options_frame.pack(fill=tk.X, pady=10, padx=10)
        
        # 样式选择
        ttk.Label(options_frame, text="字幕样式:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.style_var = tk.StringVar(value="random")
        style_combo = ttk.Combobox(options_frame, textvariable=self.style_var, 
                                  values=["random", "style1", "style2", "style3", "style4", "style5", "style6"])
        style_combo.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        style_combo.current(0)
        
        # 语言选择
        ttk.Label(options_frame, text="字幕语言:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.lang_var = tk.StringVar(value="malay")
        lang_combo = ttk.Combobox(options_frame, textvariable=self.lang_var, 
                                 values=["malay", "thai"])
        lang_combo.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        lang_combo.current(0)
        
        # QuickTime兼容模式
        self.quicktime_var = tk.BooleanVar(value=False)
        quicktime_check = ttk.Checkbutton(options_frame, text="QuickTime兼容模式", variable=self.quicktime_var)
        quicktime_check.grid(row=2, column=0, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        # 图片位置设置
        position_frame = ttk.LabelFrame(self.single_tab, text="图片位置设置")
        position_frame.pack(fill=tk.X, pady=10, padx=10)
        
        ttk.Label(position_frame, text="水平位置系数 (0-1):").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.img_x_var = tk.DoubleVar(value=0.15)
        img_x_entry = ttk.Entry(position_frame, textvariable=self.img_x_var, width=10)
        img_x_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(position_frame, text="垂直位置偏移 (像素):").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.img_y_var = tk.IntVar(value=120)
        img_y_entry = ttk.Entry(position_frame, textvariable=self.img_y_var, width=10)
        img_y_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        # 处理按钮
        btn_frame = ttk.Frame(self.single_tab)
        btn_frame.pack(pady=20)
        
        process_btn = ttk.Button(btn_frame, text="处理视频", command=self.process_single_video)
        process_btn.pack(side=tk.LEFT, padx=5)
        
        cancel_btn = ttk.Button(btn_frame, text="取消", command=self.cancel_processing)
        cancel_btn.pack(side=tk.LEFT, padx=5)
    
    def init_batch_tab(self):
        """初始化批量处理选项卡"""
        # 选项框架
        options_frame = ttk.LabelFrame(self.batch_tab, text="批量处理选项")
        options_frame.pack(fill=tk.X, pady=10, padx=10)
        
        # 样式选择
        ttk.Label(options_frame, text="字幕样式:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.batch_style_var = tk.StringVar(value="random")
        style_combo = ttk.Combobox(options_frame, textvariable=self.batch_style_var, 
                                  values=["random", "style1", "style2", "style3", "style4", "style5", "style6"])
        style_combo.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        style_combo.current(0)
        
        # 语言选择
        ttk.Label(options_frame, text="字幕语言:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.batch_lang_var = tk.StringVar(value="malay")
        lang_combo = ttk.Combobox(options_frame, textvariable=self.batch_lang_var, 
                                 values=["malay", "thai"])
        lang_combo.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        lang_combo.current(0)
        
        # QuickTime兼容模式
        self.batch_quicktime_var = tk.BooleanVar(value=False)
        quicktime_check = ttk.Checkbutton(options_frame, text="QuickTime兼容模式", variable=self.batch_quicktime_var)
        quicktime_check.grid(row=2, column=0, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        # 图片位置设置
        position_frame = ttk.LabelFrame(self.batch_tab, text="图片位置设置")
        position_frame.pack(fill=tk.X, pady=10, padx=10)
        
        ttk.Label(position_frame, text="水平位置系数 (0-1):").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.batch_img_x_var = tk.DoubleVar(value=0.15)
        img_x_entry = ttk.Entry(position_frame, textvariable=self.batch_img_x_var, width=10)
        img_x_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(position_frame, text="垂直位置偏移 (像素):").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.batch_img_y_var = tk.IntVar(value=120)
        img_y_entry = ttk.Entry(position_frame, textvariable=self.batch_img_y_var, width=10)
        img_y_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        # 目录信息
        info_frame = ttk.LabelFrame(self.batch_tab, text="目录信息")
        info_frame.pack(fill=tk.X, pady=10, padx=10)
        
        videos_dir = get_data_path("input/videos")
        output_dir = get_data_path("output")
        
        ttk.Label(info_frame, text=f"视频目录: {videos_dir}").pack(anchor=tk.W, padx=5, pady=2)
        ttk.Label(info_frame, text=f"输出目录: {output_dir}").pack(anchor=tk.W, padx=5, pady=2)
        
        # 打开目录按钮
        btn_frame = ttk.Frame(info_frame)
        btn_frame.pack(fill=tk.X, pady=5)
        
        open_videos_btn = ttk.Button(btn_frame, text="打开视频目录", 
                                    command=lambda: os.system(f'open "{videos_dir}"') if sys.platform == 'darwin' else (os.startfile(videos_dir) if sys.platform == 'win32' else os.system(f'xdg-open "{videos_dir}"')))
        open_videos_btn.pack(side=tk.LEFT, padx=5)
        
        open_output_btn = ttk.Button(btn_frame, text="打开输出目录", 
                                    command=lambda: os.system(f'open "{output_dir}"') if sys.platform == 'darwin' else (os.startfile(output_dir) if sys.platform == 'win32' else os.system(f'xdg-open "{output_dir}"')))
        open_output_btn.pack(side=tk.LEFT, padx=5)
        
        # 处理按钮 - 放在明显的位置
        process_frame = ttk.Frame(self.batch_tab)
        process_frame.pack(pady=20)
        
        # 使用大按钮，更加明显
        process_btn = ttk.Button(process_frame, text="开始批量处理所有视频", command=self.process_batch_videos, style="Big.TButton")
        self.style.configure("Big.TButton", font=("Arial", 12, "bold"), padding=10)
        process_btn.pack(side=tk.LEFT, padx=5)
        
        cancel_btn = ttk.Button(process_frame, text="取消处理", command=self.cancel_processing)
        cancel_btn.pack(side=tk.LEFT, padx=5)
    
    def init_settings_tab(self):
        """初始化设置选项卡"""
        # 设置框架
        settings_frame = ttk.LabelFrame(self.settings_tab, text="全局设置")
        settings_frame.pack(fill=tk.X, pady=10, padx=10)
        
        # 默认样式
        ttk.Label(settings_frame, text="默认字幕样式:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.default_style_var = tk.StringVar(value="random")
        style_combo = ttk.Combobox(settings_frame, textvariable=self.default_style_var, 
                                  values=["random", "style1", "style2", "style3", "style4", "style5", "style6"])
        style_combo.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        style_combo.current(0)
        
        # 默认语言
        ttk.Label(settings_frame, text="默认字幕语言:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.default_lang_var = tk.StringVar(value="malay")
        lang_combo = ttk.Combobox(settings_frame, textvariable=self.default_lang_var, 
                                 values=["malay", "thai"])
        lang_combo.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        lang_combo.current(0)
        
        # 默认QuickTime兼容模式
        self.default_quicktime_var = tk.BooleanVar(value=False)
        quicktime_check = ttk.Checkbutton(settings_frame, text="默认启用QuickTime兼容模式", 
                                         variable=self.default_quicktime_var)
        quicktime_check.grid(row=2, column=0, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        # 默认图片位置设置
        position_frame = ttk.LabelFrame(self.settings_tab, text="默认图片位置设置")
        position_frame.pack(fill=tk.X, pady=10, padx=10)
        
        ttk.Label(position_frame, text="默认水平位置系数 (0-1):").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.default_img_x_var = tk.DoubleVar(value=0.15)
        img_x_entry = ttk.Entry(position_frame, textvariable=self.default_img_x_var, width=10)
        img_x_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(position_frame, text="默认垂直位置偏移 (像素):").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.default_img_y_var = tk.IntVar(value=120)
        img_y_entry = ttk.Entry(position_frame, textvariable=self.default_img_y_var, width=10)
        img_y_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        # 保存设置按钮
        save_btn = ttk.Button(self.settings_tab, text="保存设置", command=self.save_settings)
        save_btn.pack(pady=10)
        
        # 重置设置按钮
        reset_btn = ttk.Button(self.settings_tab, text="重置为默认设置", command=self.reset_settings)
        reset_btn.pack(pady=5)
    
    def browse_video(self):
        """浏览选择视频文件"""
        file_path = filedialog.askopenfilename(
            title="选择视频文件",
            filetypes=[("视频文件", "*.mp4 *.mov *.avi *.wmv *.mkv"), ("所有文件", "*.*")]
        )
        if file_path:
            self.video_path_var.set(file_path)
            # 自动生成输出路径
            video_name = os.path.basename(file_path)
            video_name_without_ext = os.path.splitext(video_name)[0]
            output_dir = get_data_path("output")
            output_path = os.path.join(output_dir, f"{video_name_without_ext}_processed.mp4")
            self.output_path_var.set(output_path)
    
    def browse_output(self):
        """浏览选择输出文件路径"""
        file_path = filedialog.asksaveasfilename(
            title="保存视频文件",
            defaultextension=".mp4",
            filetypes=[("MP4视频", "*.mp4"), ("所有文件", "*.*")]
        )
        if file_path:
            self.output_path_var.set(file_path)
    
    def process_single_video(self):
        """处理单个视频"""
        video_path = self.video_path_var.get()
        output_path = self.output_path_var.get()
        
        if not video_path:
            messagebox.showerror("错误", "请选择视频文件")
            return
        
        if not output_path:
            messagebox.showerror("错误", "请指定输出文件路径")
            return
        
        # 获取处理参数
        style = self.style_var.get()
        lang = self.lang_var.get()
        quicktime_compatible = self.quicktime_var.get()
        img_position_x = self.img_x_var.get()
        img_position_y = self.img_y_var.get()
        
        # 启动处理线程
        self.stop_event.clear()
        self.processing_thread = threading.Thread(
            target=self._process_single_video_thread,
            args=(video_path, output_path, style, lang, quicktime_compatible, img_position_x, img_position_y)
        )
        self.processing_thread.daemon = True
        self.processing_thread.start()
        
        # 更新状态
        self.status_label.config(text="正在处理视频...")
        self.progress.start(10)
    
    def _process_single_video_thread(self, video_path, output_path, style, lang, quicktime_compatible, img_position_x, img_position_y):
        """处理单个视频的线程函数"""
        try:
            result = process_video(
                video_path, 
                output_path, 
                style=style, 
                subtitle_lang=lang, 
                quicktime_compatible=quicktime_compatible,
                img_position_x=img_position_x,
                img_position_y=img_position_y
            )
            
            if self.stop_event.is_set():
                return
            
            # 在主线程中更新UI
            self.root.after(0, self._update_ui_after_single_processing, result, output_path)
        except Exception as e:
            if self.stop_event.is_set():
                return
            
            # 在主线程中显示错误
            self.root.after(0, self._show_error, f"处理视频时出错: {e}")
    
    def _update_ui_after_single_processing(self, result, output_path):
        """处理完成后更新UI"""
        self.progress.stop()
        
        if result:
            self.status_label.config(text="处理完成")
            messagebox.showinfo("成功", f"视频处理成功\n输出文件: {output_path}")
        else:
            self.status_label.config(text="处理失败")
            messagebox.showerror("失败", "视频处理失败")
    
    def process_batch_videos(self):
        """批量处理视频"""
        # 确认开始批量处理
        if not messagebox.askyesno("确认", "确定要开始批量处理所有视频吗？"):
            return
            
        # 获取处理参数
        style = self.batch_style_var.get()
        lang = self.batch_lang_var.get()
        quicktime_compatible = self.batch_quicktime_var.get()
        img_position_x = self.batch_img_x_var.get()
        img_position_y = self.batch_img_y_var.get()
        
        # 启动处理线程
        self.stop_event.clear()
        self.processing_thread = threading.Thread(
            target=self._process_batch_videos_thread,
            args=(style, lang, quicktime_compatible, img_position_x, img_position_y)
        )
        self.processing_thread.daemon = True
        self.processing_thread.start()
        
        # 更新状态
        self.status_label.config(text="正在批量处理视频...")
        self.progress.start(10)
    
    def _process_batch_videos_thread(self, style, lang, quicktime_compatible, img_position_x, img_position_y):
        """批量处理视频的线程函数"""
        try:
            # 显示处理开始的消息框
            self.root.after(0, lambda: messagebox.showinfo("处理开始", "批量处理已开始，请等待完成..."))
            
            success_count = batch_process_videos(
                style=style,
                subtitle_lang=lang,
                quicktime_compatible=quicktime_compatible,
                img_position_x=img_position_x,
                img_position_y=img_position_y
            )
            
            if self.stop_event.is_set():
                return
            
            # 在主线程中更新UI
            self.root.after(0, self._update_ui_after_batch_processing, success_count)
        except Exception as e:
            if self.stop_event.is_set():
                return
            
            # 在主线程中显示错误
            self.root.after(0, self._show_error, f"批量处理视频时出错: {e}")
    
    def _update_ui_after_batch_processing(self, success_count):
        """批量处理完成后更新UI"""
        self.progress.stop()
        self.status_label.config(text="批量处理完成")
        
        messagebox.showinfo("批量处理完成", f"成功处理 {success_count} 个视频")
    
    def _show_error(self, error_message):
        """显示错误消息"""
        self.progress.stop()
        self.status_label.config(text="处理出错")
        messagebox.showerror("错误", error_message)
    
    def cancel_processing(self):
        """取消处理"""
        if self.processing_thread and self.processing_thread.is_alive():
            if messagebox.askyesno("确认", "确定要取消当前处理吗？"):
                self.stop_event.set()
                self.status_label.config(text="正在取消...")
                
                # 等待线程结束
                self.processing_thread.join(0.1)
                
                self.progress.stop()
                self.status_label.config(text="已取消")
                messagebox.showinfo("取消", "处理已取消")
    
    def load_settings(self):
        """加载设置"""
        # 这里可以从配置文件加载设置
        # 现在使用默认值
        self.default_style_var.set("random")
        self.default_lang_var.set("malay")
        self.default_quicktime_var.set(False)
        self.default_img_x_var.set(0.15)
        self.default_img_y_var.set(120)
        
        # 应用默认设置到其他选项卡
        self.apply_default_settings()
    
    def save_settings(self):
        """保存设置"""
        # 这里可以将设置保存到配置文件
        # 现在只是应用设置到其他选项卡
        self.apply_default_settings()
        messagebox.showinfo("设置", "设置已保存")
    
    def apply_default_settings(self):
        """应用默认设置到其他选项卡"""
        # 单个视频处理选项卡
        self.style_var.set(self.default_style_var.get())
        self.lang_var.set(self.default_lang_var.get())
        self.quicktime_var.set(self.default_quicktime_var.get())
        self.img_x_var.set(self.default_img_x_var.get())
        self.img_y_var.set(self.default_img_y_var.get())
        
        # 批量处理选项卡
        self.batch_style_var.set(self.default_style_var.get())
        self.batch_lang_var.set(self.default_lang_var.get())
        self.batch_quicktime_var.set(self.default_quicktime_var.get())
        self.batch_img_x_var.set(self.default_img_x_var.get())
        self.batch_img_y_var.set(self.default_img_y_var.get())
    
    def reset_settings(self):
        """重置为默认设置"""
        self.default_style_var.set("random")
        self.default_lang_var.set("malay")
        self.default_quicktime_var.set(False)
        self.default_img_x_var.set(0.15)
        self.default_img_y_var.set(120)
        
        self.apply_default_settings()
        messagebox.showinfo("设置", "已重置为默认设置")

if __name__ == "__main__":
    # 创建根窗口
    root = tk.Tk()
    
    # 创建应用
    app = VideoProcessorApp(root)
    
    # 运行主循环
    root.mainloop() 