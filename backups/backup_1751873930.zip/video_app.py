#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频处理应用程序入口
"""

import os
import sys
import argparse
from pathlib import Path

from video_core import process_video, batch_process_videos
from utils import get_data_path, get_video_info

def parse_arguments():
    """解析命令行参数"""
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='视频处理工具')
    parser.add_argument('--video', help='要处理的视频文件路径')
    parser.add_argument('--output', help='输出视频文件路径')
    parser.add_argument('--style', help='字幕样式', choices=['style1', 'style2', 'style3', 'style4', 'style5', 'style6', 'random'])
    parser.add_argument('--lang', help='字幕语言', choices=['malay', 'thai', 'random'])
    parser.add_argument('--batch', action='store_true', help='批量处理所有视频')
    parser.add_argument('--quicktime', action='store_true', help='生成QuickTime兼容的视频')
    parser.add_argument('--debug', action='store_true', help='启用调试模式')
    parser.add_argument('--img-x', type=float, default=0.15, help='图片水平位置系数（视频宽度的百分比，默认0.15）')
    parser.add_argument('--img-y', type=int, default=120, help='图片垂直位置偏移（相对于背景位置，默认120像素向下偏移）')
    
    return parser.parse_args()

def main():
    """主函数"""
    args = parse_arguments()
    
    # 处理style和lang参数
    style = "random" if args.style == 'random' else (None if args.style is None else args.style)
    subtitle_lang = "random" if args.lang == 'random' else (None if args.lang is None else args.lang)
    
    # 批量处理模式
    if args.batch:
        batch_process_videos(
            style=style,  # 如果为None或"random"，每个视频随机选择样式
            subtitle_lang=subtitle_lang,  # 如果为None或"random"，每个视频随机选择语言
            quicktime_compatible=args.quicktime,
            img_position_x=args.img_x,
            img_position_y=args.img_y
        )
        return
        
    # 单个视频处理模式
    if args.video:
        video_path = args.video
        output_path = args.output
        
        # 如果未指定输出路径，则生成一个
        if not output_path:
            video_name = os.path.basename(video_path)
            video_name_without_ext = os.path.splitext(video_name)[0]
            output_dir = get_data_path("output")
            output_path = os.path.join(output_dir, f"{video_name_without_ext}_processed.mp4")
        
        # 处理视频
        result = process_video(
            video_path, 
            output_path, 
            style=style,  # 如果为None，随机选择样式
            subtitle_lang=subtitle_lang,  # 如果为None，随机选择语言
            quicktime_compatible=args.quicktime,
            img_position_x=args.img_x,
            img_position_y=args.img_y
        )
        
        if result:
            print(f"视频处理成功: {output_path}")
        else:
            print("视频处理失败")
        
        return
    
    # 如果没有指定视频文件和批处理模式，则启动GUI
    try:
        # 导入GUI模块
        from video_app_gui import VideoProcessorApp
        import tkinter as tk
        
        # 创建根窗口
        root = tk.Tk()
        
        # 创建应用
        app = VideoProcessorApp(root)
        
        # 运行主循环
        root.mainloop()
    except ImportError:
        print("无法启动GUI，请安装tkinter或使用命令行参数")
        sys.exit(1)
    except Exception as e:
        print(f"启动GUI时出错: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
