#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试视频处理功能
"""

import os
import sys
import argparse
from pathlib import Path

# 导入视频处理模块
from video_core import process_video, batch_process_videos
from utils import get_video_info, get_data_path

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='视频处理测试工具')
    parser.add_argument('-v', '--video', help='指定要处理的视频文件')
    parser.add_argument('-b', '--batch', action='store_true', help='批量处理所有视频')
    parser.add_argument('-s', '--style', default='style1', help='字幕样式')
    parser.add_argument('-o', '--output', help='输出文件路径')
    args = parser.parse_args()
    
    # 处理单个视频
    if args.video:
        video_path = args.video
        output_path = args.output
        
        # 检查视频是否存在
        if not os.path.exists(video_path):
            print(f"错误: 视频文件不存在: {video_path}")
            return 1
            
        # 显示视频信息
        video_info = get_video_info(video_path)
        if video_info:
            width, height, duration = video_info
            print(f"视频信息: {width}x{height}, {duration}秒")
            print(f"视频长度判断: {'短视频 (需要正放+倒放)' if duration < 9.0 else '长视频 (直接处理)'}")
        
        # 处理视频
        result = process_video(video_path, output_path, args.style)
        if result:
            print(f"处理成功: {result}")
            return 0
        else:
            print("处理失败")
            return 1
    
    # 批量处理
    elif args.batch:
        video_dir = get_data_path("input/videos")
        print(f"批量处理目录: {video_dir}")
        
        # 检查目录是否存在
        if not os.path.exists(video_dir):
            print(f"错误: 视频目录不存在: {video_dir}")
            return 1
            
        # 统计视频文件数量
        video_files = []
        for ext in ['.mp4', '.avi', '.mov', '.MP4', '.AVI', '.MOV']:
            video_files.extend(list(Path(video_dir).glob(f"*{ext}")))
            
        if not video_files:
            print(f"错误: 视频目录中没有找到视频文件")
            return 1
            
        print(f"找到 {len(video_files)} 个视频文件")
        
        # 显示每个视频的长度判断
        for video_file in video_files:
            video_info = get_video_info(video_file)
            if video_info:
                _, _, duration = video_info
                print(f"{video_file.name}: {duration:.1f}秒 - {'短视频' if duration < 9.0 else '长视频'}")
        
        # 确认是否继续
        confirm = input("\n确认批量处理这些视频? (y/n): ")
        if confirm.lower() not in ['y', 'yes']:
            print("已取消")
            return 0
            
        # 批量处理
        success_count = batch_process_videos(args.style)
        print(f"处理完成: {success_count}/{len(video_files)} 成功")
        return 0
    
    else:
        parser.print_help()
        print("\n请使用 -v 指定视频文件或 -b 进行批量处理")
        return 1

if __name__ == "__main__":
    sys.exit(main())
